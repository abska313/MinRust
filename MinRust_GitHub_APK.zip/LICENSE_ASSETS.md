# Asset Attribution & Originality Notice

All textures (`assets/textures/voxel_atlas.png`, `assets/textures/app_icon.png`, `assets/textures/icons/*.png`), vector icons (`icon.svg`), and sound effects (`assets/audio/*.wav`) included in **MinRust** were procedurally generated specifically for this project.

No copyrighted third-party art, characters, logos, audio, or code from Minecraft, Rust, or any other commercial game are included. You are free to modify, replace, and expand all files in this project.
