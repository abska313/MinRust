extends Node
## Offline JSON Save/Load manager for MinRust worlds, modified blocks, and player state.

const SAVE_DIR := "user://saves"
const SAVE_FILE := "user://saves/minrust_world.json"


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_FILE)


func save_world(data: Dictionary) -> bool:
	DirAccess.make_dir_recursive_absolute(SAVE_DIR)
	var file := FileAccess.open(SAVE_FILE, FileAccess.WRITE)
	if file == null:
		push_error("SaveManager: Could not open save file for writing.")
		return false
	data["saved_at"] = Time.get_unix_time_from_system()
	data["version"] = GameConfig.VERSION
	file.store_string(JSON.stringify(data))
	file.close()
	return true


func load_world() -> Dictionary:
	if not has_save():
		return {}
	var file := FileAccess.open(SAVE_FILE, FileAccess.READ)
	if file == null:
		return {}
	var raw := file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(raw)
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}
	return parsed


func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(SAVE_FILE)
