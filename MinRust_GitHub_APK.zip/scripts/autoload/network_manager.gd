extends Node
## Host-Authoritative Same-Wi-Fi LAN Multiplayer Manager for MinRust.
## Uses ENetMultiplayerPeer (UDP 7777) for gameplay sync + PacketPeerUDP (UDP 7778)
## for automatic local Wi-Fi room discovery, with manual IP:Port fallback.

signal lan_rooms_updated(rooms: Dictionary)
signal peer_list_changed(peers: Dictionary)
signal connection_status_changed(status_text: String, is_error: bool)
signal host_disconnected()

var peers_info: Dictionary = {} # peer_id -> {"name": String}
var discovered_rooms: Dictionary = {} # ip -> {"host_name", "ip", "port", "players", "last_seen"}

var _broadcaster: PacketPeerUDP = null
var _listener: PacketPeerUDP = null
var _broadcast_timer: float = 0.0
var _cleanup_timer: float = 0.0


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)


func _process(delta: float) -> void:
	# Host periodically broadcasts room presence on local Wi-Fi
	if _broadcaster != null and GameConfig.session_mode == GameConfig.SessionMode.LAN_HOST:
		_broadcast_timer += delta
		if _broadcast_timer >= 1.5:
			_broadcast_timer = 0.0
			_send_lan_beacon()

	# Client/Menu listens for LAN room broadcasts
	if _listener != null:
		while _listener.get_available_packet_count() > 0:
			var pkt := _listener.get_packet()
			var sender_ip := _listener.get_packet_ip()
			var text := pkt.get_string_from_utf8()
			var parsed = JSON.parse_string(text)
			if typeof(parsed) == TYPE_DICTIONARY and parsed.get("game", "") == GameConfig.GAME_TITLE:
				discovered_rooms[sender_ip] = {
					"host_name": str(parsed.get("host_name", "Host")),
					"ip": sender_ip,
					"port": int(parsed.get("port", GameConfig.LAN_GAME_PORT)),
					"players": int(parsed.get("players", 1)),
					"max_players": int(parsed.get("max_players", GameConfig.MAX_LAN_PLAYERS)),
					"last_seen": Time.get_unix_time_from_system()
				}
				lan_rooms_updated.emit(discovered_rooms)

		_cleanup_timer += delta
		if _cleanup_timer >= 2.0:
			_cleanup_timer = 0.0
			var now := Time.get_unix_time_from_system()
			var removed := false
			for ip in discovered_rooms.keys():
				if now - float(discovered_rooms[ip]["last_seen"]) > 5.0:
					discovered_rooms.erase(ip)
					removed = true
			if removed:
				lan_rooms_updated.emit(discovered_rooms)


func start_solo_offline() -> void:
	close_session()
	GameConfig.session_mode = GameConfig.SessionMode.SOLO_OFFLINE
	peers_info = {1: {"name": GameConfig.player_name}}
	connection_status_changed.emit("وضع أوفلاين فردي (Offline Solo)", false)


func host_lan_game(port: int = GameConfig.LAN_GAME_PORT) -> Error:
	close_session()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, GameConfig.MAX_LAN_PLAYERS)
	if err != OK:
		connection_status_changed.emit("فشل تشغيل الاستضافة على المنفذ %d (تأكد من الواي فاي)" % port, true)
		return err

	multiplayer.multiplayer_peer = peer
	GameConfig.session_mode = GameConfig.SessionMode.LAN_HOST
	GameConfig.target_host_port = port
	peers_info = {1: {"name": GameConfig.player_name}}

	_start_lan_broadcast()
	var local_ip := get_local_lan_ip()
	connection_status_changed.emit("مضيف على الواي فاي | IP: %s:%d" % [local_ip, port], false)
	peer_list_changed.emit(peers_info)
	return OK


func join_lan_game(ip: String, port: int = GameConfig.LAN_GAME_PORT) -> Error:
	close_session()
	var clean_ip := ip.strip_edges()
	if clean_ip.is_empty():
		connection_status_changed.emit("يرجى إدخال عنوان IP صحيح للمضيف.", true)
		return ERR_INVALID_PARAMETER

	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(clean_ip, port)
	if err != OK:
		connection_status_changed.emit("تعذر الاتصال بـ %s:%d" % [clean_ip, port], true)
		return err

	multiplayer.multiplayer_peer = peer
	GameConfig.session_mode = GameConfig.SessionMode.LAN_CLIENT
	GameConfig.target_host_ip = clean_ip
	GameConfig.target_host_port = port
	connection_status_changed.emit("جاري الاتصال بـ %s:%d..." % [clean_ip, port], false)
	return OK


func start_lan_discovery() -> void:
	stop_lan_discovery()
	discovered_rooms.clear()
	_listener = PacketPeerUDP.new()
	var err := _listener.bind(GameConfig.LAN_DISCOVERY_PORT)
	if err != OK:
		_listener = null


func stop_lan_discovery() -> void:
	if _listener != null:
		_listener.close()
		_listener = null


func _start_lan_broadcast() -> void:
	if _broadcaster != null:
		_broadcaster.close()
	_broadcaster = PacketPeerUDP.new()
	_broadcaster.set_broadcast_enabled(true)
	_broadcaster.set_dest_address("255.255.255.255", GameConfig.LAN_DISCOVERY_PORT)


func _send_lan_beacon() -> void:
	if _broadcaster == null:
		return
	var payload := {
		"game": GameConfig.GAME_TITLE,
		"host_name": GameConfig.player_name,
		"port": GameConfig.target_host_port,
		"players": peers_info.size(),
		"max_players": GameConfig.MAX_LAN_PLAYERS
	}
	_broadcaster.put_packet(JSON.stringify(payload).to_utf8_buffer())


func close_session() -> void:
	if _broadcaster != null:
		_broadcaster.close()
		_broadcaster = null
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	peers_info.clear()


func is_networked() -> bool:
	return GameConfig.session_mode != GameConfig.SessionMode.SOLO_OFFLINE and multiplayer.multiplayer_peer != null


func is_host_authority() -> bool:
	if not is_networked():
		return true
	return multiplayer.is_server()


func get_local_lan_ip() -> String:
	var addresses := IP.get_local_addresses()
	for addr in addresses:
		if addr.begins_with("192.168.") or addr.begins_with("10.") or addr.begins_with("172."):
			if not addr.contains(":"):
				return addr
	return "127.0.0.1"


func _on_peer_connected(id: int) -> void:
	if multiplayer.is_server():
		peers_info[id] = {"name": "Player_%d" % id}
		peer_list_changed.emit(peers_info)


func _on_peer_disconnected(id: int) -> void:
	if peers_info.has(id):
		peers_info.erase(id)
		peer_list_changed.emit(peers_info)


func _on_connected_to_server() -> void:
	connection_status_changed.emit("تم الاتصال بالمضيف بنجاح!", false)
	rpc_id(1, "register_player_name", GameConfig.player_name)


func _on_connection_failed() -> void:
	connection_status_changed.emit("فشل الاتصال بالمضيف. تأكد أن الجهازين على نفس الواي فاي.", true)
	close_session()


func _on_server_disconnected() -> void:
	connection_status_changed.emit("انقطع الاتصال بالمضيف (Host Left).", true)
	close_session()
	host_disconnected.emit()


@rpc("any_peer", "reliable")
func register_player_name(p_name: String) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	var safe_name := p_name.strip_edges().substr(0, 18)
	if safe_name.is_empty():
		safe_name = "Player_%d" % sender_id
	peers_info[sender_id] = {"name": safe_name}
	peer_list_changed.emit(peers_info)
