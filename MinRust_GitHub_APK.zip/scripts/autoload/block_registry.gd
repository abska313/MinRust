extends Node
## Registry of all voxel blocks in MinRust (Minecraft voxel blocks + Rust building/survival tiers).

const ATLAS_COLS := 16
const ATLAS_ROWS := 2

enum BlockID {
	AIR = 0,
	GRASS = 1,
	DIRT = 2,
	STONE = 3,
	WOOD_LOG = 4,
	LEAVES = 5,
	SAND = 6,
	IRON_ORE = 7,
	SULFUR_ORE = 8,
	BEDROCK = 9,
	TWIG_BLOCK = 10,
	WOOD_WALL = 11,
	STONE_WALL = 12,
	METAL_WALL = 13,
	DOOR_WOOD_CLOSED = 14,
	DOOR_WOOD_OPEN = 15,
	DOOR_METAL_CLOSED = 16,
	DOOR_METAL_OPEN = 17,
	CAMPFIRE = 18,
	TOOL_CUPBOARD = 19,
	LOOT_BARREL = 20,
	STORAGE_BOX = 21,
	WATER = 22
}

var _blocks: Dictionary = {}


func _ready() -> void:
	_register_all_blocks()


func _register_all_blocks() -> void:
	# id: { name, ar_name, solid, transparent, max_hp, top, side, bottom, drop_item, drop_count, sound, upgrade_to, upgrade_cost }
	_blocks[BlockID.AIR] = {
		"name": "Air", "ar_name": "هواء", "solid": false, "transparent": true, "max_hp": 0,
		"top": 0, "side": 0, "bottom": 0, "drop_item": "", "drop_count": 0, "sound": "stone",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.GRASS] = {
		"name": "Grass", "ar_name": "عشب", "solid": true, "transparent": false, "max_hp": 30,
		"top": 0, "side": 1, "bottom": 2, "drop_item": "stone", "drop_count": 1, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.DIRT] = {
		"name": "Dirt", "ar_name": "تراب", "solid": true, "transparent": false, "max_hp": 25,
		"top": 2, "side": 2, "bottom": 2, "drop_item": "stone", "drop_count": 1, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.STONE] = {
		"name": "Stone", "ar_name": "حجر", "solid": true, "transparent": false, "max_hp": 60,
		"top": 3, "side": 3, "bottom": 3, "drop_item": "stone", "drop_count": 4, "sound": "stone",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.WOOD_LOG] = {
		"name": "Tree Wood", "ar_name": "خشب شجر", "solid": true, "transparent": false, "max_hp": 45,
		"top": 4, "side": 4, "bottom": 4, "drop_item": "wood", "drop_count": 6, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.LEAVES] = {
		"name": "Leaves", "ar_name": "أوراق", "solid": true, "transparent": false, "max_hp": 12,
		"top": 5, "side": 5, "bottom": 5, "drop_item": "cloth", "drop_count": 1, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.SAND] = {
		"name": "Sand", "ar_name": "رمل", "solid": true, "transparent": false, "max_hp": 20,
		"top": 6, "side": 6, "bottom": 6, "drop_item": "stone", "drop_count": 1, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.IRON_ORE] = {
		"name": "Metal Ore", "ar_name": "خام حديد", "solid": true, "transparent": false, "max_hp": 80,
		"top": 7, "side": 7, "bottom": 7, "drop_item": "metal", "drop_count": 5, "sound": "metal",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.SULFUR_ORE] = {
		"name": "Sulfur Ore", "ar_name": "خام كبريت", "solid": true, "transparent": false, "max_hp": 70,
		"top": 8, "side": 8, "bottom": 8, "drop_item": "sulfur", "drop_count": 4, "sound": "stone",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.BEDROCK] = {
		"name": "Bedrock", "ar_name": "صخر أساس", "solid": true, "transparent": false, "max_hp": 999999,
		"top": 9, "side": 9, "bottom": 9, "drop_item": "", "drop_count": 0, "sound": "metal",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	# Rust Building Tiers: Twig -> Wood -> Stone -> Sheet Metal
	_blocks[BlockID.TWIG_BLOCK] = {
		"name": "Twig Block", "ar_name": "بناء أغصان (مستوى 1)", "solid": true, "transparent": false, "max_hp": 25,
		"top": 10, "side": 10, "bottom": 10, "drop_item": "wood", "drop_count": 1, "sound": "wood",
		"upgrade_to": BlockID.WOOD_WALL, "upgrade_cost": {"wood": 4}
	}
	_blocks[BlockID.WOOD_WALL] = {
		"name": "Wood Wall", "ar_name": "جدار خشبي (مستوى 2)", "solid": true, "transparent": false, "max_hp": 100,
		"top": 11, "side": 11, "bottom": 11, "drop_item": "wood", "drop_count": 3, "sound": "wood",
		"upgrade_to": BlockID.STONE_WALL, "upgrade_cost": {"stone": 5}
	}
	_blocks[BlockID.STONE_WALL] = {
		"name": "Stone Wall", "ar_name": "جدار حجري (مستوى 3)", "solid": true, "transparent": false, "max_hp": 250,
		"top": 12, "side": 12, "bottom": 12, "drop_item": "stone", "drop_count": 4, "sound": "stone",
		"upgrade_to": BlockID.METAL_WALL, "upgrade_cost": {"metal": 5}
	}
	_blocks[BlockID.METAL_WALL] = {
		"name": "Sheet Metal Wall", "ar_name": "جدار حديدي (مستوى 4)", "solid": true, "transparent": false, "max_hp": 500,
		"top": 13, "side": 13, "bottom": 13, "drop_item": "metal", "drop_count": 4, "sound": "metal",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.DOOR_WOOD_CLOSED] = {
		"name": "Wood Door (Closed)", "ar_name": "باب خشبي (مغلق)", "solid": true, "transparent": false, "max_hp": 120,
		"top": 14, "side": 14, "bottom": 14, "drop_item": "wood", "drop_count": 4, "sound": "wood",
		"upgrade_to": BlockID.DOOR_METAL_CLOSED, "upgrade_cost": {"metal": 4}
	}
	_blocks[BlockID.DOOR_WOOD_OPEN] = {
		"name": "Wood Door (Open)", "ar_name": "باب خشبي (مفتوح)", "solid": false, "transparent": true, "max_hp": 120,
		"top": 14, "side": 14, "bottom": 14, "drop_item": "wood", "drop_count": 4, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.DOOR_METAL_CLOSED] = {
		"name": "Metal Door (Closed)", "ar_name": "باب حديدي (مغلق)", "solid": true, "transparent": false, "max_hp": 300,
		"top": 15, "side": 15, "bottom": 15, "drop_item": "metal", "drop_count": 4, "sound": "metal",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.DOOR_METAL_OPEN] = {
		"name": "Metal Door (Open)", "ar_name": "باب حديدي (مفتوح)", "solid": false, "transparent": true, "max_hp": 300,
		"top": 15, "side": 15, "bottom": 15, "drop_item": "metal", "drop_count": 4, "sound": "metal",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.CAMPFIRE] = {
		"name": "Campfire", "ar_name": "نار المخيم", "solid": true, "transparent": false, "max_hp": 60,
		"top": 16, "side": 16, "bottom": 3, "drop_item": "wood", "drop_count": 3, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.TOOL_CUPBOARD] = {
		"name": "Tool Cupboard (TC)", "ar_name": "خزانة الحماية (TC)", "solid": true, "transparent": false, "max_hp": 200,
		"top": 17, "side": 17, "bottom": 11, "drop_item": "wood", "drop_count": 6, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.LOOT_BARREL] = {
		"name": "Scrap Barrel", "ar_name": "برميل خردة", "solid": true, "transparent": false, "max_hp": 35,
		"top": 18, "side": 18, "bottom": 18, "drop_item": "metal", "drop_count": 4, "sound": "metal",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.STORAGE_BOX] = {
		"name": "Storage Box", "ar_name": "صندوق تخزين", "solid": true, "transparent": false, "max_hp": 90,
		"top": 19, "side": 19, "bottom": 11, "drop_item": "wood", "drop_count": 4, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}
	_blocks[BlockID.WATER] = {
		"name": "Water", "ar_name": "ماء", "solid": false, "transparent": true, "max_hp": 0,
		"top": 20, "side": 20, "bottom": 20, "drop_item": "", "drop_count": 0, "sound": "wood",
		"upgrade_to": BlockID.AIR, "upgrade_cost": {}
	}


func get_block(id: int) -> Dictionary:
	return _blocks.get(id, _blocks[BlockID.AIR])


func is_solid(id: int) -> bool:
	return bool(get_block(id).get("solid", false))


func is_transparent(id: int) -> bool:
	return bool(get_block(id).get("transparent", true))


func get_tile_uv(tile_index: int) -> Rect2:
	var col := tile_index % ATLAS_COLS
	var row := tile_index / ATLAS_COLS
	var u_size := 1.0 / float(ATLAS_COLS)
	var v_size := 1.0 / float(ATLAS_ROWS)
	# Small UV inset prevents texture bleeding on mobile GPUs
	var pad := 0.0015
	return Rect2(
		Vector2(col * u_size + pad, row * v_size + pad),
		Vector2(u_size - pad * 2.0, v_size - pad * 2.0)
	)
