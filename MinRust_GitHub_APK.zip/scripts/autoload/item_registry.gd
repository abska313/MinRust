extends Node
## Registry of tools, weapons, resources, consumables, placeable structures, and crafting recipes.

var items: Dictionary = {}
var recipes: Array[Dictionary] = []


func _ready() -> void:
	_register_items()
	_register_recipes()


func _register_items() -> void:
	# Starter & Harvest Tools
	items["rock"] = {
		"name": "Rust Rock", "ar_name": "صخرة البداية", "type": "tool",
		"wood_dmg": 12, "stone_dmg": 12, "metal_dmg": 8, "entity_dmg": 12,
		"icon": "res://assets/textures/icons/rock.png"
	}
	items["hatchet"] = {
		"name": "Stone Hatchet", "ar_name": "فأس حجري", "type": "tool",
		"wood_dmg": 28, "stone_dmg": 10, "metal_dmg": 12, "entity_dmg": 18,
		"icon": "res://assets/textures/icons/hatchet.png"
	}
	items["pickaxe"] = {
		"name": "Stone Pickaxe", "ar_name": "معول حجري", "type": "tool",
		"wood_dmg": 10, "stone_dmg": 30, "metal_dmg": 26, "entity_dmg": 16,
		"icon": "res://assets/textures/icons/pickaxe.png"
	}
	items["hammer"] = {
		"name": "Building Hammer", "ar_name": "مطرقة الترقية", "type": "hammer",
		"wood_dmg": 6, "stone_dmg": 6, "metal_dmg": 6, "entity_dmg": 8,
		"icon": "res://assets/textures/icons/hammer.png"
	}
	items["spear"] = {
		"name": "Wooden Spear", "ar_name": "رمح خشبي", "type": "weapon",
		"wood_dmg": 8, "stone_dmg": 6, "metal_dmg": 8, "entity_dmg": 34,
		"icon": "res://assets/textures/icons/spear.png"
	}

	# Raw Resources
	items["wood"] = {
		"name": "Wood", "ar_name": "خشب", "type": "resource",
		"icon": "res://assets/textures/icons/wood.png"
	}
	items["stone"] = {
		"name": "Stone", "ar_name": "حجر", "type": "resource",
		"icon": "res://assets/textures/icons/stone.png"
	}
	items["metal"] = {
		"name": "Metal Frags", "ar_name": "قطع حديد", "type": "resource",
		"icon": "res://assets/textures/icons/metal.png"
	}
	items["sulfur"] = {
		"name": "Sulfur", "ar_name": "كبريت", "type": "resource",
		"icon": "res://assets/textures/icons/stone.png"
	}
	items["cloth"] = {
		"name": "Cloth", "ar_name": "قماش", "type": "resource",
		"icon": "res://assets/textures/icons/bandage.png"
	}
	items["raw_meat"] = {
		"name": "Raw Meat", "ar_name": "لحم نيء", "type": "resource",
		"icon": "res://assets/textures/icons/cooked_meat.png"
	}

	# Placeable Building Blocks
	items["twig_block"] = {
		"name": "Twig Block", "ar_name": "كتلة بناء", "type": "placeable",
		"block_id": BlockRegistry.BlockID.TWIG_BLOCK,
		"icon": "res://assets/textures/icons/twig_block.png"
	}
	items["door_wood"] = {
		"name": "Wood Door", "ar_name": "باب خشبي", "type": "placeable",
		"block_id": BlockRegistry.BlockID.DOOR_WOOD_CLOSED,
		"icon": "res://assets/textures/icons/door_wood.png"
	}
	items["campfire"] = {
		"name": "Campfire", "ar_name": "نار مخيم", "type": "placeable",
		"block_id": BlockRegistry.BlockID.CAMPFIRE,
		"icon": "res://assets/textures/icons/campfire.png"
	}
	items["tool_cupboard"] = {
		"name": "Tool Cupboard", "ar_name": "خزانة حماية (TC)", "type": "placeable",
		"block_id": BlockRegistry.BlockID.TOOL_CUPBOARD,
		"icon": "res://assets/textures/icons/tool_cupboard.png"
	}

	# Consumables
	items["bandage"] = {
		"name": "Bandage", "ar_name": "ضمادة", "type": "consumable",
		"heal": 30.0, "hunger": 0.0, "thirst": 0.0,
		"icon": "res://assets/textures/icons/bandage.png"
	}
	items["cooked_meat"] = {
		"name": "Cooked Meat", "ar_name": "لحم مشوي", "type": "consumable",
		"heal": 12.0, "hunger": 38.0, "thirst": 0.0,
		"icon": "res://assets/textures/icons/cooked_meat.png"
	}
	items["water_canteen"] = {
		"name": "Water Canteen", "ar_name": "قنينة ماء", "type": "consumable",
		"heal": 5.0, "hunger": 0.0, "thirst": 45.0,
		"icon": "res://assets/textures/icons/water_canteen.png"
	}


func _register_recipes() -> void:
	recipes = [
		{"id": "twig_block", "out_count": 4, "cost": {"wood": 4}, "category": "Build"},
		{"id": "door_wood", "out_count": 1, "cost": {"wood": 8}, "category": "Build"},
		{"id": "campfire", "out_count": 1, "cost": {"wood": 6, "stone": 4}, "category": "Survival"},
		{"id": "tool_cupboard", "out_count": 1, "cost": {"wood": 15}, "category": "Build"},
		{"id": "hatchet", "out_count": 1, "cost": {"wood": 6, "stone": 4}, "category": "Tools"},
		{"id": "pickaxe", "out_count": 1, "cost": {"wood": 6, "stone": 6}, "category": "Tools"},
		{"id": "hammer", "out_count": 1, "cost": {"wood": 5, "stone": 2}, "category": "Tools"},
		{"id": "spear", "out_count": 1, "cost": {"wood": 8, "stone": 2}, "category": "Tools"},
		{"id": "bandage", "out_count": 2, "cost": {"cloth": 2}, "category": "Survival"},
		{"id": "cooked_meat", "out_count": 1, "cost": {"raw_meat": 1, "wood": 1}, "category": "Survival"},
		{"id": "water_canteen", "out_count": 1, "cost": {"cloth": 1, "wood": 2}, "category": "Survival"},
	]


func get_item(item_id: String) -> Dictionary:
	return items.get(item_id, {})
