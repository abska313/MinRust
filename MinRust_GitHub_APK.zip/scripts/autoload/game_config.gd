extends Node
## Global configuration, user settings, and session state for MinRust.

const GAME_TITLE := "MinRust"
const VERSION := "1.0.0"

# LAN Multiplayer Defaults (Same Wi-Fi)
const LAN_GAME_PORT := 7777
const LAN_DISCOVERY_PORT := 7778
const MAX_LAN_PLAYERS := 8

# Session Mode
enum SessionMode { SOLO_OFFLINE, LAN_HOST, LAN_CLIENT }

var session_mode: SessionMode = SessionMode.SOLO_OFFLINE
var player_name: String = "Survivor"
var world_seed: int = 133742
var load_saved_world: bool = false
var target_host_ip: String = "127.0.0.1"
var target_host_port: int = LAN_GAME_PORT

# Mobile-First User Settings
var touch_sensitivity: float = 0.0055
var render_distance_chunks: int = 3 # 7x7 chunks around player — smooth 60 FPS on phones
var sfx_volume: float = 0.85
var ambience_volume: float = 0.55
var invert_y: bool = false

const SETTINGS_PATH := "user://minrust_settings.cfg"


func _ready() -> void:
	load_settings()


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("profile", "player_name", player_name)
	cfg.set_value("controls", "touch_sensitivity", touch_sensitivity)
	cfg.set_value("controls", "invert_y", invert_y)
	cfg.set_value("graphics", "render_distance_chunks", render_distance_chunks)
	cfg.set_value("audio", "sfx_volume", sfx_volume)
	cfg.set_value("audio", "ambience_volume", ambience_volume)
	cfg.save(SETTINGS_PATH)


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	player_name = str(cfg.get_value("profile", "player_name", player_name))
	touch_sensitivity = float(cfg.get_value("controls", "touch_sensitivity", touch_sensitivity))
	invert_y = bool(cfg.get_value("controls", "invert_y", invert_y))
	render_distance_chunks = clampi(int(cfg.get_value("graphics", "render_distance_chunks", render_distance_chunks)), 2, 5)
	sfx_volume = clampf(float(cfg.get_value("audio", "sfx_volume", sfx_volume)), 0.0, 1.0)
	ambience_volume = clampf(float(cfg.get_value("audio", "ambience_volume", ambience_volume)), 0.0, 1.0)
