extends Node
## Lightweight pooled audio manager for mobile-friendly SFX and campfire ambience.

const SFX_FILES := {
	"hit_wood": "res://assets/audio/hit_wood.wav",
	"hit_stone": "res://assets/audio/hit_stone.wav",
	"hit_metal": "res://assets/audio/hit_metal.wav",
	"place_block": "res://assets/audio/place_block.wav",
	"upgrade_hammer": "res://assets/audio/upgrade_hammer.wav",
	"footstep": "res://assets/audio/footstep.wav",
	"jump": "res://assets/audio/jump.wav",
	"hurt": "res://assets/audio/hurt.wav",
	"craft": "res://assets/audio/craft.wav",
	"door_toggle": "res://assets/audio/door_toggle.wav",
	"ui_click": "res://assets/audio/ui_click.wav",
}

var _streams: Dictionary = {}
var _pool: Array[AudioStreamPlayer] = []
var _pool_index: int = 0
var _ambience_player: AudioStreamPlayer


func _ready() -> void:
	for key in SFX_FILES.keys():
		var path: String = SFX_FILES[key]
		if ResourceLoader.exists(path):
			_streams[key] = load(path)

	for i in range(8):
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)

	_ambience_player = AudioStreamPlayer.new()
	add_child(_ambience_player)
	if ResourceLoader.exists("res://assets/audio/campfire_loop.wav"):
		var stream := load("res://assets/audio/campfire_loop.wav")
		if stream is AudioStreamWAV:
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		_ambience_player.stream = stream


func play_sfx(sfx_name: String, pitch_jitter: float = 0.06) -> void:
	if not _streams.has(sfx_name):
		return
	var player := _pool[_pool_index]
	_pool_index = (_pool_index + 1) % _pool.size()
	player.stream = _streams[sfx_name]
	player.volume_db = linear_to_db(maxf(GameConfig.sfx_volume, 0.001))
	player.pitch_scale = randf_range(1.0 - pitch_jitter, 1.0 + pitch_jitter)
	player.play()


func set_campfire_ambience(active: bool) -> void:
	if _ambience_player == null or _ambience_player.stream == null:
		return
	if active:
		_ambience_player.volume_db = linear_to_db(maxf(GameConfig.ambience_volume * 0.6, 0.001))
		if not _ambience_player.playing:
			_ambience_player.play()
	else:
		if _ambience_player.playing:
			_ambience_player.stop()
