class_name VirtualJoystick
extends Control
## Multi-touch safe Virtual Joystick for mobile movement + outer-ring sprint detection.

signal moved(vector: Vector2, is_sprinting: bool)

@export var max_radius: float = 68.0
@export var deadzone: float = 0.14

var _touch_index: int = -1
var _center: Vector2 = Vector2.ZERO
var _knob_offset: Vector2 = Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	_center = size * 0.5


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		_center = size * 0.5
		queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			_touch_index = event.index
			_update_knob(event.position)
			accept_event()
		elif not event.pressed and event.index == _touch_index:
			_reset_knob()
			accept_event()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		_update_knob(event.position)
		accept_event()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and _touch_index == -1:
			_touch_index = 99
			_update_knob(event.position)
			accept_event()
		elif not event.pressed and _touch_index == 99:
			_reset_knob()
			accept_event()
	elif event is InputEventMouseMotion and _touch_index == 99:
		_update_knob(event.position)
		accept_event()


func _update_knob(local_pos: Vector2) -> void:
	var delta := local_pos - _center
	var dist := delta.length()
	if dist > max_radius:
		delta = delta.normalized() * max_radius
		dist = max_radius
	_knob_offset = delta
	var norm := delta / max_radius
	if norm.length() < deadzone:
		moved.emit(Vector2.ZERO, false)
	else:
		var sprint := norm.length() > 0.88 and norm.y < -0.55
		moved.emit(norm, sprint)
	queue_redraw()


func _reset_knob() -> void:
	_touch_index = -1
	_knob_offset = Vector2.ZERO
	moved.emit(Vector2.ZERO, false)
	queue_redraw()


func _draw() -> void:
	var base_col := Color(0.11, 0.13, 0.16, 0.52)
	var ring_col := Color(0.85, 0.36, 0.15, 0.80)
	var knob_col := Color(0.92, 0.94, 0.96, 0.88)
	draw_circle(_center, max_radius, base_col)
	draw_arc(_center, max_radius, 0.0, TAU, 40, ring_col, 3.0)
	draw_circle(_center + _knob_offset, 28.0, knob_col)
	draw_arc(_center + _knob_offset, 28.0, 0.0, TAU, 24, ring_col, 2.0)
