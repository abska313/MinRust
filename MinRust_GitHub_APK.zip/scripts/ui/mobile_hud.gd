class_name MobileHUD
extends CanvasLayer
## Mobile-first HUD for MinRust: survival bars, virtual joystick, multi-touch look pad,
## ergonomic action buttons, 6-slot touch hotbar, context target hint, crafting, and pause.

var _player: PlayerController = null
var _world: VoxelWorld = null
var _day_night: DayNightCycle = null

var _look_touch_idx: int = -1
var _toast_timer: float = 0.0
var _hotbar_buttons: Array[Button] = []

@onready var health_bar: ProgressBar = $Root/TopLeft/VBox/HealthBar
@onready var hunger_bar: ProgressBar = $Root/TopLeft/VBox/HungerBar
@onready var thirst_bar: ProgressBar = $Root/TopLeft/VBox/ThirstBar
@onready var warmth_bar: ProgressBar = $Root/TopLeft/VBox/WarmthBar
@onready var clock_label: Label = $Root/TopCenter/ClockLabel
@onready var lan_badge: Label = $Root/TopCenter/LanBadge
@onready var target_hint: Label = $Root/TargetHint
@onready var toast_label: Label = $Root/ToastLabel
@onready var joystick: VirtualJoystick = $Root/VirtualJoystick
@onready var look_pad: Control = $Root/LookPad
@onready var hotbar_box: HBoxContainer = $Root/HotbarPanel/HotbarBox
@onready var crafting_panel: CraftingPanel = $Root/CraftingPanel
@onready var pause_menu: PauseMenu = $Root/PauseMenu

@onready var btn_mine: Button = $Root/ActionButtons/BtnMine
@onready var btn_use: Button = $Root/ActionButtons/BtnUse
@onready var btn_jump: Button = $Root/ActionButtons/BtnJump
@onready var btn_crouch: Button = $Root/ActionButtons/BtnCrouch
@onready var btn_craft: Button = $Root/TopRight/BtnCraft
@onready var btn_save: Button = $Root/TopRight/BtnSave
@onready var btn_pause: Button = $Root/TopRight/BtnPause


func _ready() -> void:
	_player = get_node_or_null("../Player")
	_world = get_node_or_null("../VoxelWorld")
	_day_night = get_node_or_null("../DayNightCycle")

	_build_hotbar_buttons()

	if _player != null:
		_player.stats_changed.connect(_refresh_stats)
		_player.inventory_changed.connect(_refresh_hotbar)
		_player.target_hint_changed.connect(_on_target_hint)
		_player.toast_message.connect(show_toast)
		joystick.moved.connect(_on_joystick_moved)

	btn_mine.pressed.connect(func(): if _player: _player.perform_primary_action())
	btn_use.pressed.connect(func(): if _player: _player.perform_secondary_action())
	btn_jump.pressed.connect(func(): if _player: _player.queue_jump())
	btn_crouch.pressed.connect(func(): if _player: _player.toggle_crouch())

	btn_craft.pressed.connect(_on_toggle_craft)
	btn_save.pressed.connect(_on_save_pressed)
	btn_pause.pressed.connect(_on_toggle_pause)
	look_pad.gui_input.connect(_on_look_pad_input)

	NetworkManager.host_disconnected.connect(_on_host_disconnected)
	_refresh_lan_badge()
	_refresh_stats()
	_refresh_hotbar()


func _process(delta: float) -> void:
	if _day_night != null and clock_label != null:
		clock_label.text = _day_night.get_clock_string()

	if _toast_timer > 0.0:
		_toast_timer -= delta
		if _toast_timer <= 0.0 and toast_label != null:
			toast_label.visible = false


func _build_hotbar_buttons() -> void:
	for child in hotbar_box.get_children():
		child.queue_free()
	_hotbar_buttons.clear()

	for i in range(6):
		var b := Button.new()
		b.custom_minimum_size = Vector2(78, 66)
		b.expand_icon = true
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
		b.add_theme_font_size_override("font_size", 12)
		var slot_index := i
		b.pressed.connect(func():
			AudioManager.play_sfx("ui_click")
			if _player != null:
				_player.select_hotbar_slot(slot_index)
		)
		hotbar_box.add_child(b)
		_hotbar_buttons.append(b)


func _on_joystick_moved(vec: Vector2, sprinting: bool) -> void:
	if _player != null:
		_player.move_input = vec
		_player.is_sprinting = sprinting


func _on_look_pad_input(event: InputEvent) -> void:
	if _player == null:
		return
	if event is InputEventScreenTouch:
		if event.pressed and _look_touch_idx == -1:
			_look_touch_idx = event.index
		elif not event.pressed and event.index == _look_touch_idx:
			_look_touch_idx = -1
	elif event is InputEventScreenDrag and event.index == _look_touch_idx:
		_player.apply_look_delta(event.relative)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_player.apply_look_delta(event.relative)


func _refresh_stats() -> void:
	if _player == null:
		return
	health_bar.value = _player.health
	hunger_bar.value = _player.hunger
	thirst_bar.value = _player.thirst
	warmth_bar.value = _player.warmth


func _refresh_hotbar() -> void:
	if _player == null:
		return
	for i in range(_hotbar_buttons.size()):
		var b := _hotbar_buttons[i]
		var item_id := _player.hotbar[i] if i < _player.hotbar.size() else ""
		var info := ItemRegistry.get_item(item_id)
		var count := _player.get_item_count(item_id)
		if item_id.is_empty() or info.is_empty():
			b.text = "%d" % (i + 1)
			b.icon = null
		else:
			var short_name := str(info.get("name", item_id))
			b.text = "%s (%d)" % [short_name.substr(0, 7), count]
			var icon_path := str(info.get("icon", ""))
			if not icon_path.is_empty() and ResourceLoader.exists(icon_path):
				b.icon = load(icon_path)
		b.modulate = Color(1.0, 0.72, 0.45, 1.0) if i == _player.active_slot else Color(0.86, 0.88, 0.92, 0.92)


func _refresh_lan_badge() -> void:
	if lan_badge == null:
		return
	match GameConfig.session_mode:
		GameConfig.SessionMode.SOLO_OFFLINE:
			lan_badge.text = "SOLO OFFLINE"
		GameConfig.SessionMode.LAN_HOST:
			lan_badge.text = "WIFI HOST | IP: %s:%d" % [NetworkManager.get_local_lan_ip(), GameConfig.target_host_port]
		GameConfig.SessionMode.LAN_CLIENT:
			lan_badge.text = "WIFI CLIENT | %s" % GameConfig.target_host_ip


func _on_target_hint(hint_text: String) -> void:
	if target_hint == null:
		return
	target_hint.text = hint_text
	target_hint.visible = not hint_text.is_empty()


func show_toast(msg: String) -> void:
	if toast_label == null:
		return
	toast_label.text = msg
	toast_label.visible = true
	_toast_timer = 2.8


func _on_toggle_craft() -> void:
	AudioManager.play_sfx("ui_click")
	if crafting_panel != null:
		crafting_panel.toggle_panel(_player)


func _on_save_pressed() -> void:
	AudioManager.play_sfx("ui_click")
	if _world != null and _world.save_game_now():
		show_toast("تم حفظ العالم بنجاح!")
	else:
		show_toast("تعذر الحفظ حالياً.")


func _on_toggle_pause() -> void:
	AudioManager.play_sfx("ui_click")
	if pause_menu != null:
		pause_menu.toggle_pause(_world)


func _on_host_disconnected() -> void:
	show_toast("انقطع الاتصال بالمضيف — جاري العودة للقائمة الرئيسية...")
	await get_tree().create_timer(2.0).timeout
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
