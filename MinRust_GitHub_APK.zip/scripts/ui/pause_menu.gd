class_name PauseMenu
extends PanelContainer
## Mobile Pause & Settings overlay with audio sliders, touch sensitivity, LAN info, and exit.

var _world: VoxelWorld = null

@onready var lan_info_label: Label = $VBox/LanInfoLabel
@onready var sfx_slider: HSlider = $VBox/SfxRow/SfxSlider
@onready var sens_slider: HSlider = $VBox/SensRow/SensSlider
@onready var btn_resume: Button = $VBox/BtnResume
@onready var btn_save_quit: Button = $VBox/BtnSaveQuit


func _ready() -> void:
	visible = false
	sfx_slider.value = GameConfig.sfx_volume
	sens_slider.value = GameConfig.touch_sensitivity * 1000.0

	sfx_slider.value_changed.connect(func(v: float):
		GameConfig.sfx_volume = clampf(v, 0.0, 1.0)
		GameConfig.save_settings()
	)
	sens_slider.value_changed.connect(func(v: float):
		GameConfig.touch_sensitivity = clampf(v / 1000.0, 0.002, 0.015)
		GameConfig.save_settings()
	)
	btn_resume.pressed.connect(func():
		AudioManager.play_sfx("ui_click")
		visible = false
	)
	btn_save_quit.pressed.connect(_on_save_and_quit)


func toggle_pause(world_ref: VoxelWorld) -> void:
	_world = world_ref
	visible = not visible
	if visible:
		if GameConfig.session_mode == GameConfig.SessionMode.LAN_HOST:
			lan_info_label.text = "عنوان الواي فاي للانضمام: %s : %d" % [NetworkManager.get_local_lan_ip(), GameConfig.target_host_port]
		elif GameConfig.session_mode == GameConfig.SessionMode.LAN_CLIENT:
			lan_info_label.text = "متصل بالمضيف: %s : %d" % [GameConfig.target_host_ip, GameConfig.target_host_port]
		else:
			lan_info_label.text = "وضع أوفلاين فردي (لا يحتاج إنترنت)"


func _on_save_and_quit() -> void:
	AudioManager.play_sfx("ui_click")
	if _world != null and NetworkManager.is_host_authority():
		_world.save_game_now()
	NetworkManager.close_session()
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
