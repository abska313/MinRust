class_name CraftingPanel
extends PanelContainer
## Touch-friendly Crafting & Resource inventory drawer for MinRust.

var _player: PlayerController = null

@onready var resources_label: Label = $VBox/ResourcesLabel
@onready var recipes_box: VBoxContainer = $VBox/Scroll/RecipesBox
@onready var btn_close: Button = $VBox/Header/BtnClose


func _ready() -> void:
	visible = false
	btn_close.pressed.connect(func():
		AudioManager.play_sfx("ui_click")
		visible = false
	)


func toggle_panel(player_ref: PlayerController) -> void:
	_player = player_ref
	visible = not visible
	if visible:
		refresh()


func refresh() -> void:
	if _player == null:
		return
	resources_label.text = "خشب: %d  |  حجر: %d  |  حديد: %d  |  قماش: %d  |  لحم نيء: %d" % [
		_player.get_item_count("wood"),
		_player.get_item_count("stone"),
		_player.get_item_count("metal"),
		_player.get_item_count("cloth"),
		_player.get_item_count("raw_meat"),
	]

	for child in recipes_box.get_children():
		child.queue_free()

	for recipe in ItemRegistry.recipes:
		var row := HBoxContainer.new()
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		var out_id := str(recipe["id"])
		var item_info := ItemRegistry.get_item(out_id)
		var ar_name := str(item_info.get("ar_name", out_id))
		var out_count := int(recipe["out_count"])

		var cost_parts: Array[String] = []
		var cost_dict: Dictionary = recipe["cost"]
		for k in cost_dict.keys():
			var res_ar := str(ItemRegistry.get_item(str(k)).get("ar_name", str(k)))
			cost_parts.append("%s x%d" % [res_ar, int(cost_dict[k])])

		var lbl := Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.text = "%s (x%d)  —  المطلوب: %s" % [ar_name, out_count, ", ".join(cost_parts)]
		row.add_child(lbl)

		var btn := Button.new()
		btn.custom_minimum_size = Vector2(115, 44)
		btn.text = "تصنيع (Craft)"
		btn.disabled = not _player.has_resources(cost_dict)
		var captured_recipe := recipe
		btn.pressed.connect(func():
			if _player.craft_recipe(captured_recipe):
				refresh()
		)
		row.add_child(btn)
		recipes_box.add_child(row)
