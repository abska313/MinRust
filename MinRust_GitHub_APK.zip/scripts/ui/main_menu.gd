class_name MainMenu
extends Control
## MinRust Main Menu: Offline Solo, Continue Save, Host Same-Wi-Fi LAN,
## Auto-Discovered LAN Rooms + Manual IP:Port Fallback.

@onready var name_input: LineEdit = $Center/Panel/VBox/NameRow/NameInput
@onready var btn_solo: Button = $Center/Panel/VBox/ButtonsRow/BtnSolo
@onready var btn_continue: Button = $Center/Panel/VBox/ButtonsRow/BtnContinue
@onready var btn_host_lan: Button = $Center/Panel/VBox/LanRow/BtnHostLan
@onready var ip_input: LineEdit = $Center/Panel/VBox/JoinRow/IpInput
@onready var btn_join_ip: Button = $Center/Panel/VBox/JoinRow/BtnJoinIp
@onready var rooms_box: VBoxContainer = $Center/Panel/VBox/RoomsPanel/RoomsScroll/RoomsBox
@onready var status_label: Label = $Center/Panel/VBox/StatusLabel


func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	name_input.text = GameConfig.player_name
	ip_input.text = GameConfig.target_host_ip
	btn_continue.disabled = not SaveManager.has_save()

	btn_solo.pressed.connect(_on_play_solo)
	btn_continue.pressed.connect(_on_continue_save)
	btn_host_lan.pressed.connect(_on_host_lan)
	btn_join_ip.pressed.connect(_on_join_manual_ip)

	NetworkManager.lan_rooms_updated.connect(_refresh_rooms_list)
	NetworkManager.connection_status_changed.connect(_on_connection_status)
	multiplayer.connected_to_server.connect(_on_client_connected_enter_world)

	NetworkManager.start_lan_discovery()
	_refresh_rooms_list(NetworkManager.discovered_rooms)


func _exit_tree() -> void:
	NetworkManager.stop_lan_discovery()


func _apply_player_name() -> void:
	var n := name_input.text.strip_edges()
	GameConfig.player_name = n if not n.is_empty() else "Survivor"
	GameConfig.save_settings()


func _on_play_solo() -> void:
	AudioManager.play_sfx("ui_click")
	_apply_player_name()
	GameConfig.load_saved_world = false
	GameConfig.world_seed = randi() % 999999 + 1000
	NetworkManager.start_solo_offline()
	get_tree().change_scene_to_file("res://scenes/world.tscn")


func _on_continue_save() -> void:
	AudioManager.play_sfx("ui_click")
	_apply_player_name()
	GameConfig.load_saved_world = true
	NetworkManager.start_solo_offline()
	get_tree().change_scene_to_file("res://scenes/world.tscn")


func _on_host_lan() -> void:
	AudioManager.play_sfx("ui_click")
	_apply_player_name()
	GameConfig.load_saved_world = SaveManager.has_save()
	var err := NetworkManager.host_lan_game(GameConfig.LAN_GAME_PORT)
	if err == OK:
		get_tree().change_scene_to_file("res://scenes/world.tscn")


func _on_join_manual_ip() -> void:
	AudioManager.play_sfx("ui_click")
	_apply_player_name()
	GameConfig.load_saved_world = false
	NetworkManager.join_lan_game(ip_input.text, GameConfig.LAN_GAME_PORT)


func _on_client_connected_enter_world() -> void:
	if GameConfig.session_mode == GameConfig.SessionMode.LAN_CLIENT:
		get_tree().change_scene_to_file("res://scenes/world.tscn")


func _on_connection_status(text: String, is_error: bool) -> void:
	status_label.text = text
	status_label.modulate = Color(1.0, 0.45, 0.38) if is_error else Color(0.75, 0.92, 0.72)


func _refresh_rooms_list(rooms: Dictionary) -> void:
	for child in rooms_box.get_children():
		child.queue_free()

	if rooms.is_empty():
		var empty_lbl := Label.new()
		empty_lbl.text = "جاري البحث عن غرف على نفس الواي فاي... (أو أدخل الـ IP يدوياً)"
		empty_lbl.modulate = Color(0.78, 0.82, 0.86)
		rooms_box.add_child(empty_lbl)
		return

	for ip in rooms.keys():
		var r: Dictionary = rooms[ip]
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(0, 50)
		btn.text = "انضمام: %s  (%s:%d)  [%d/%d]" % [
			str(r["host_name"]), str(r["ip"]), int(r["port"]), int(r["players"]), int(r["max_players"])
		]
		var target_ip := str(r["ip"])
		var target_port := int(r["port"])
		btn.pressed.connect(func():
			AudioManager.play_sfx("ui_click")
			_apply_player_name()
			GameConfig.load_saved_world = false
			NetworkManager.join_lan_game(target_ip, target_port)
		)
		rooms_box.add_child(btn)
