class_name RaiderEnemy
extends CharacterBody3D
## Procedural 3D Voxel Scrap Raider with ground physics, ledge-jumping, patrol/chase AI, and loot drops.

const MOVE_SPEED := 3.4
const CHASE_RANGE := 18.0
const ATTACK_RANGE := 2.0
const GRAVITY := 24.0

var hp: int = 75
var _attack_cooldown: float = 0.0
var _wander_dir: Vector3 = Vector3.ZERO
var _wander_timer: float = 0.0
var _player: PlayerController = null

@onready var hp_label: Label3D = $HPLabel


func _ready() -> void:
	collision_layer = 4 # Enemies
	collision_mask = 1 | 2 # WorldTerrain + Player
	_player = get_node_or_null("../../Player")
	_update_hp_label()


func _physics_process(delta: float) -> void:
	if _attack_cooldown > 0.0:
		_attack_cooldown -= delta

	if not is_on_floor():
		velocity.y -= GRAVITY * delta

	var move_dir := Vector3.ZERO
	if _player != null and is_instance_valid(_player):
		var to_player := _player.global_position - global_position
		var horiz := Vector3(to_player.x, 0.0, to_player.z)
		var dist := horiz.length()
		if dist <= ATTACK_RANGE and absf(to_player.y) < 1.8:
			if _attack_cooldown <= 0.0:
				_attack_cooldown = 1.25
				_player.take_damage(12.0)
		elif dist <= CHASE_RANGE:
			move_dir = horiz.normalized()
		else:
			_wander_timer -= delta
			if _wander_timer <= 0.0:
				_wander_timer = randf_range(2.5, 5.0)
				var a := randf() * TAU
				_wander_dir = Vector3(cos(a), 0.0, sin(a))
			move_dir = _wander_dir * 0.45

	velocity.x = lerpf(velocity.x, move_dir.x * MOVE_SPEED, 8.0 * delta)
	velocity.z = lerpf(velocity.z, move_dir.z * MOVE_SPEED, 8.0 * delta)

	if move_dir.length_squared() > 0.01:
		rotation.y = lerp_angle(rotation.y, atan2(move_dir.x, move_dir.z), 8.0 * delta)

	move_and_slide()

	# Jump cleanly over 1-block obstacles when chasing
	if is_on_floor() and is_on_wall() and move_dir.length_squared() > 0.05:
		velocity.y = 7.8


func take_damage(amount: int, knockback_dir: Vector3, attacker: Node = null) -> void:
	hp -= amount
	velocity += knockback_dir * 5.0 + Vector3(0.0, 3.2, 0.0)
	_update_hp_label()
	if hp <= 0:
		if attacker != null and attacker.has_method("add_item"):
			attacker.add_item("raw_meat", 2)
			attacker.add_item("cloth", 2)
			attacker.add_item("metal", 2)
		queue_free()


func _update_hp_label() -> void:
	if hp_label != null:
		hp_label.text = "Raider %d HP" % maxi(hp, 0)
