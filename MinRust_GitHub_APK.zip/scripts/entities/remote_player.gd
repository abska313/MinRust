class_name RemotePlayer
extends Node3D
## Interpolated 3D voxel survivor avatar for family members playing over the same Wi-Fi LAN.

var _target_pos: Vector3 = Vector3.ZERO
var _target_yaw: float = 0.0
var _swing_phase: float = 0.0

@onready var name_label: Label3D = $NameLabel
@onready var right_arm: MeshInstance3D = $RightArm


func _ready() -> void:
	_target_pos = global_position


func set_player_label(pname: String) -> void:
	if name_label != null:
		name_label.text = pname


func apply_network_state(pos: Vector3, yaw: float, swinging: bool, pname: String) -> void:
	_target_pos = pos
	_target_yaw = yaw
	if swinging:
		_swing_phase = 1.0
	if name_label != null and name_label.text != pname:
		name_label.text = pname


func _process(delta: float) -> void:
	global_position = global_position.lerp(_target_pos, clampf(14.0 * delta, 0.0, 1.0))
	rotation.y = lerp_angle(rotation.y, _target_yaw, clampf(14.0 * delta, 0.0, 1.0))

	if _swing_phase > 0.0:
		_swing_phase = maxf(0.0, _swing_phase - delta * 4.0)
	if right_arm != null:
		right_arm.rotation.x = -sin(_swing_phase * PI) * 1.1
