class_name PlayerController
extends CharacterBody3D
## Mobile-first 3D CharacterBody3D controller with reliable physics/collision,
## Rust survival stats, voxel harvesting/building/upgrading, crafting, and LAN sync.

signal stats_changed()
signal inventory_changed()
signal target_hint_changed(hint_text: String)
signal toast_message(msg: String)
signal player_died()

const WALK_SPEED := 5.4
const SPRINT_SPEED := 7.6
const CROUCH_SPEED := 2.8
const JUMP_VELOCITY := 8.6
const GRAVITY := 24.0
const ACCEL_GROUND := 16.0
const ACCEL_AIR := 4.5
const STAND_HEIGHT := 1.72
const CROUCH_HEIGHT := 1.15

# Survival Stats (0..100)
var health: float = 100.0
var hunger: float = 100.0
var thirst: float = 100.0
var warmth: float = 85.0
var stamina: float = 100.0

# Inventory & 6-Slot Mobile Hotbar
var inventory: Dictionary = {
	"rock": 1,
	"hammer": 1,
	"wood": 20,
	"stone": 12,
	"twig_block": 8,
	"cooked_meat": 2,
	"water_canteen": 1,
	"bandage": 1
}
var hotbar: Array[String] = ["rock", "hammer", "twig_block", "cooked_meat", "water_canteen", "bandage"]
var active_slot: int = 0

# Mobile Touch Input State
var move_input: Vector2 = Vector2.ZERO
var is_sprinting: bool = false
var is_crouching: bool = false
var _jump_queued: bool = false

# Timers & Animation
var _pitch: float = 0.0
var _step_timer: float = 0.0
var _action_cooldown: float = 0.0
var _swing_anim: float = 0.0
var _net_sync_timer: float = 0.0
var _world: VoxelWorld = null
var _day_night: DayNightCycle = null

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var collider: CollisionShape3D = $CollisionShape3D
@onready var tool_pivot: Node3D = $Head/Camera3D/ToolPivot
@onready var tool_mesh: MeshInstance3D = $Head/Camera3D/ToolPivot/ToolMesh


func _ready() -> void:
	collision_layer = 2 # Player
	collision_mask = 1 | 4 # WorldTerrain + Interactables
	floor_max_angle = deg_to_rad(46.0)
	floor_snap_length = 0.25

	_world = get_node_or_null("../VoxelWorld")
	_day_night = get_node_or_null("../DayNightCycle")
	_update_tool_visual()
	stats_changed.emit()
	inventory_changed.emit()


func _unhandled_input(event: InputEvent) -> void:
	# Desktop fallback controls for testing in Godot Editor
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		apply_look_delta(event.relative * 0.6)
	elif event is InputEventKey and event.pressed:
		if event.keycode == KEY_SPACE:
			queue_jump()
		elif event.keycode >= KEY_1 and event.keycode <= KEY_6:
			select_hotbar_slot(event.keycode - KEY_1)
		elif event.keycode == KEY_E:
			perform_secondary_action()
		elif event.keycode == KEY_F:
			perform_primary_action()


func apply_look_delta(delta_px: Vector2) -> void:
	var sens := GameConfig.touch_sensitivity
	rotate_y(-delta_px.x * sens)
	var y_sign := 1.0 if GameConfig.invert_y else -1.0
	_pitch = clampf(_pitch + delta_px.y * sens * y_sign, deg_to_rad(-82.0), deg_to_rad(82.0))
	if head != null:
		head.rotation.x = _pitch


func queue_jump() -> void:
	_jump_queued = true


func toggle_crouch() -> void:
	if is_crouching:
		# Verify ceiling headroom before standing up so player never clips into blocks
		if _world != null:
			var head_check := Vector3i(floori(global_position.x), floori(global_position.y + 1.65), floori(global_position.z))
			if BlockRegistry.is_solid(_world.get_block_at(head_check)):
				return
		is_crouching = false
	else:
		is_crouching = true
	_apply_collider_height()


func _apply_collider_height() -> void:
	if collider != null and collider.shape is CapsuleShape3D:
		var cap: CapsuleShape3D = collider.shape
		cap.height = CROUCH_HEIGHT if is_crouching else STAND_HEIGHT
	if head != null:
		head.position.y = 0.92 if is_crouching else 1.48


func select_hotbar_slot(slot_idx: int) -> void:
	active_slot = clampi(slot_idx, 0, hotbar.size() - 1)
	_update_tool_visual()
	inventory_changed.emit()


func get_active_item_id() -> String:
	return hotbar[active_slot]


func _physics_process(delta: float) -> void:
	if _action_cooldown > 0.0:
		_action_cooldown -= delta

	# Combine mobile joystick + desktop WASD fallback
	var inp := move_input
	if inp.length_squared() < 0.01:
		var kb := Vector2.ZERO
		if Input.is_key_pressed(KEY_W): kb.y -= 1.0
		if Input.is_key_pressed(KEY_S): kb.y += 1.0
		if Input.is_key_pressed(KEY_A): kb.x -= 1.0
		if Input.is_key_pressed(KEY_D): kb.x += 1.0
		if kb.length_squared() > 0.0:
			inp = kb.normalized()

	var sprint_active := (is_sprinting or Input.is_key_pressed(KEY_SHIFT)) and not is_crouching and stamina > 8.0 and inp.y < -0.5
	var target_speed := CROUCH_SPEED if is_crouching else (SPRINT_SPEED if sprint_active else WALK_SPEED)

	var wish_dir := (transform.basis * Vector3(inp.x, 0.0, inp.y))
	wish_dir.y = 0.0
	if wish_dir.length() > 1.0:
		wish_dir = wish_dir.normalized()

	var accel := ACCEL_GROUND if is_on_floor() else ACCEL_AIR
	velocity.x = lerpf(velocity.x, wish_dir.x * target_speed, clampf(accel * delta, 0.0, 1.0))
	velocity.z = lerpf(velocity.z, wish_dir.z * target_speed, clampf(accel * delta, 0.0, 1.0))

	# Check water buoyancy vs standard gravity
	var feet_block := BlockRegistry.BlockID.AIR
	if _world != null:
		feet_block = _world.get_block_at(Vector3i(floori(global_position.x), floori(global_position.y + 0.2), floori(global_position.z)))
	var in_water := (feet_block == BlockRegistry.BlockID.WATER)

	if in_water:
		velocity.y = lerpf(velocity.y, 2.5 if _jump_queued else -1.8, 6.0 * delta)
	elif not is_on_floor():
		velocity.y -= GRAVITY * delta
		velocity.y = maxf(velocity.y, -32.0) # Terminal velocity prevents tunneling
	else:
		if _jump_queued and stamina >= 6.0:
			velocity.y = JUMP_VELOCITY
			stamina = maxf(0.0, stamina - 6.0)
			AudioManager.play_sfx("jump", 0.08)

	_jump_queued = false
	move_and_slide()

	# Safety floor rescue (if player somehow falls below bedrock)
	if global_position.y < -4.0 and _world != null:
		global_position = _world.get_safe_spawn_position(Vector2i(int(global_position.x), int(global_position.z)))
		velocity = Vector3.ZERO

	# Footstep SFX
	var horiz_speed := Vector2(velocity.x, velocity.z).length()
	if is_on_floor() and horiz_speed > 1.2:
		_step_timer += delta * (horiz_speed / WALK_SPEED)
		if _step_timer >= 0.42:
			_step_timer = 0.0
			AudioManager.play_sfx("footstep", 0.14)

	# Stamina & Survival Tick
	_tick_survival(delta, sprint_active)
	_tick_tool_animation(delta)
	_tick_target_hint()

	# LAN transform sync at ~15 Hz
	if _world != null and NetworkManager.is_networked():
		_net_sync_timer += delta
		if _net_sync_timer >= 0.066:
			_net_sync_timer = 0.0
			_world.broadcast_local_player_state(global_position, rotation.y, _swing_anim > 0.05)


func _tick_survival(delta: float, sprint_active: bool) -> void:
	if sprint_active:
		stamina = maxf(0.0, stamina - 14.0 * delta)
	else:
		stamina = minf(100.0, stamina + 16.0 * delta)

	hunger = maxf(0.0, hunger - 0.14 * delta)
	thirst = maxf(0.0, thirst - 0.20 * delta)

	var near_fire := _world != null and _world.is_near_campfire(global_position)
	AudioManager.set_campfire_ambience(near_fire)
	var is_night_now := _day_night != null and _day_night.is_night()

	if near_fire:
		warmth = minf(100.0, warmth + 14.0 * delta)
	elif is_night_now:
		warmth = maxf(0.0, warmth - 1.35 * delta)
	else:
		warmth = minf(90.0, warmth + 2.5 * delta)

	# Health drain if starving, dehydrated, or freezing
	if hunger <= 0.1 or thirst <= 0.1 or warmth <= 5.0:
		take_damage(2.0 * delta, false)
	elif hunger > 60.0 and thirst > 50.0 and warmth > 40.0 and health < 100.0:
		health = minf(100.0, health + 1.2 * delta)

	stats_changed.emit()


func _tick_tool_animation(delta: float) -> void:
	if _swing_anim > 0.0:
		_swing_anim = maxf(0.0, _swing_anim - delta * 4.2)
	if tool_pivot != null:
		var swing_rad := sin(_swing_anim * PI) * 0.85
		tool_pivot.rotation.x = -swing_rad
		tool_pivot.rotation.y = swing_rad * 0.25


func _tick_target_hint() -> void:
	if _world == null or camera == null:
		return
	var ray := _world.raycast_voxel(camera.global_position, -camera.global_transform.basis.z, 5.2)
	if not ray["hit"]:
		target_hint_changed.emit("")
		return
	var b_id: int = int(ray["block_id"])
	var info := BlockRegistry.get_block(b_id)
	var label := "%s (%d/%d HP)" % [str(info["ar_name"]), int(ray["hp"]), int(ray["max_hp"])]
	var active := get_active_item_id()
	if active == "hammer" and int(info["upgrade_to"]) != BlockRegistry.BlockID.AIR:
		var next_info := BlockRegistry.get_block(int(info["upgrade_to"]))
		label += " | زر USE للترقية -> %s" % str(next_info["ar_name"])
	elif b_id in [BlockRegistry.BlockID.DOOR_WOOD_CLOSED, BlockRegistry.BlockID.DOOR_WOOD_OPEN, BlockRegistry.BlockID.DOOR_METAL_CLOSED, BlockRegistry.BlockID.DOOR_METAL_OPEN]:
		label += " | زر USE لفتح/إغلاق الباب"
	elif b_id == BlockRegistry.BlockID.CAMPFIRE:
		label += " | تدفئة + شوي لحم"
	target_hint_changed.emit(label)


func perform_primary_action() -> void:
	# Mine / Harvest / Attack Raiders
	if _action_cooldown > 0.0 or _world == null or camera == null:
		return
	_action_cooldown = 0.28
	_swing_anim = 1.0

	var active_id := get_active_item_id()
	var item_data := ItemRegistry.get_item(active_id)

	# 1. Check melee hit against nearby Scrap Raiders first
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(
		camera.global_position,
		camera.global_position - camera.global_transform.basis.z * 3.6,
		4 # Enemies layer (bit 3 = value 4)
	)
	var hit := space.intersect_ray(q)
	if not hit.is_empty() and hit.get("collider") != null and hit["collider"].has_method("take_damage"):
		var dmg := int(item_data.get("entity_dmg", 12))
		var knock_dir := (-camera.global_transform.basis.z).normalized()
		hit["collider"].take_damage(dmg, knock_dir, self)
		AudioManager.play_sfx("hurt", 0.1)
		return

	# 2. Voxel harvest / raid block
	var ray := _world.raycast_voxel(camera.global_position, -camera.global_transform.basis.z, 5.2)
	if not ray["hit"]:
		return
	var b_id: int = int(ray["block_id"])
	var b_info := BlockRegistry.get_block(b_id)
	var snd := str(b_info.get("sound", "stone"))
	AudioManager.play_sfx("hit_" + snd, 0.1)

	var dmg_key := snd + "_dmg"
	var dmg := int(item_data.get(dmg_key, 10))
	var res := _world.request_damage_block(ray["block_pos"], dmg)
	if bool(res.get("broken", false)):
		var drop_item := str(res.get("drop_item", ""))
		var drop_count := int(res.get("drop_count", 0))
		if not drop_item.is_empty() and drop_count > 0:
			add_item(drop_item, drop_count)
		if bool(res.get("was_barrel", false)):
			add_item("cloth", 2)
			add_item("cooked_meat", 1)
			toast_message.emit("حصلت على خردة وموارد من البرميل!")


func perform_secondary_action() -> void:
	# Use consumable / Toggle Door / Upgrade with Hammer / Place Block
	if _action_cooldown > 0.0 or _world == null or camera == null:
		return
	_action_cooldown = 0.25

	var active_id := get_active_item_id()
	var item_data := ItemRegistry.get_item(active_id)

	# 1. Consumable check
	if str(item_data.get("type", "")) == "consumable" and get_item_count(active_id) > 0:
		consume_item(active_id, 1)
		health = minf(100.0, health + float(item_data.get("heal", 0.0)))
		hunger = minf(100.0, hunger + float(item_data.get("hunger", 0.0)))
		thirst = minf(100.0, thirst + float(item_data.get("thirst", 0.0)))
		AudioManager.play_sfx("craft", 0.05)
		toast_message.emit("تم استخدام %s" % str(item_data["ar_name"]))
		stats_changed.emit()
		return

	var ray := _world.raycast_voxel(camera.global_position, -camera.global_transform.basis.z, 5.2)
	if not ray["hit"]:
		return
	var target_pos: Vector3i = ray["block_pos"]
	var target_id: int = int(ray["block_id"])

	# 2. Interactive Door Toggle (solid <-> open)
	if target_id == BlockRegistry.BlockID.DOOR_WOOD_CLOSED:
		_world.request_place_or_upgrade_block(target_pos, BlockRegistry.BlockID.DOOR_WOOD_OPEN)
		AudioManager.play_sfx("door_toggle")
		return
	elif target_id == BlockRegistry.BlockID.DOOR_WOOD_OPEN:
		_world.request_place_or_upgrade_block(target_pos, BlockRegistry.BlockID.DOOR_WOOD_CLOSED)
		AudioManager.play_sfx("door_toggle")
		return
	elif target_id == BlockRegistry.BlockID.DOOR_METAL_CLOSED:
		_world.request_place_or_upgrade_block(target_pos, BlockRegistry.BlockID.DOOR_METAL_OPEN)
		AudioManager.play_sfx("door_toggle")
		return
	elif target_id == BlockRegistry.BlockID.DOOR_METAL_OPEN:
		_world.request_place_or_upgrade_block(target_pos, BlockRegistry.BlockID.DOOR_METAL_CLOSED)
		AudioManager.play_sfx("door_toggle")
		return

	# 3. Rust Building Hammer Upgrade (Twig -> Wood -> Stone -> Metal)
	if active_id == "hammer":
		var b_info := BlockRegistry.get_block(target_id)
		var next_id: int = int(b_info.get("upgrade_to", BlockRegistry.BlockID.AIR))
		if next_id != BlockRegistry.BlockID.AIR:
			var cost: Dictionary = b_info.get("upgrade_cost", {})
			if has_resources(cost):
				spend_resources(cost)
				_world.request_place_or_upgrade_block(target_pos, next_id)
				_swing_anim = 1.0
				AudioManager.play_sfx("upgrade_hammer")
				var next_name := str(BlockRegistry.get_block(next_id)["ar_name"])
				toast_message.emit("تمت الترقية إلى %s!" % next_name)
			else:
				toast_message.emit("موارد غير كافية للترقية!")
		return

	# 4. Placeable Block (verify it doesn't overlap the player collider!)
	if str(item_data.get("type", "")) == "placeable" and get_item_count(active_id) > 0:
		var place_pos: Vector3i = ray["place_pos"]
		if _would_overlap_player(place_pos):
			toast_message.emit("ابتعد خطوة حتى تقدر تبني هنا.")
			return
		var block_to_place: int = int(item_data["block_id"])
		consume_item(active_id, 1)
		_world.request_place_or_upgrade_block(place_pos, block_to_place)
		_swing_anim = 1.0
		AudioManager.play_sfx("place_block")


func _would_overlap_player(vp: Vector3i) -> bool:
	var block_aabb := AABB(Vector3(vp.x, vp.y, vp.z), Vector3.ONE)
	var player_aabb := AABB(global_position - Vector3(0.32, 0.0, 0.32), Vector3(0.64, STAND_HEIGHT, 0.64))
	return block_aabb.intersects(player_aabb)


# --- Inventory & Crafting ---
func get_item_count(item_id: String) -> int:
	return int(inventory.get(item_id, 0))


func add_item(item_id: String, amount: int) -> void:
	if amount <= 0:
		return
	inventory[item_id] = get_item_count(item_id) + amount
	# Auto-assign crafted tools/placeables to an empty hotbar slot if available
	var t := str(ItemRegistry.get_item(item_id).get("type", ""))
	if t in ["tool", "weapon", "hammer", "placeable", "consumable"] and not hotbar.has(item_id):
		for i in range(hotbar.size()):
			if hotbar[i].is_empty() or get_item_count(hotbar[i]) <= 0:
				hotbar[i] = item_id
				break
	inventory_changed.emit()


func consume_item(item_id: String, amount: int) -> bool:
	if get_item_count(item_id) < amount:
		return false
	inventory[item_id] = get_item_count(item_id) - amount
	inventory_changed.emit()
	return true


func has_resources(cost: Dictionary) -> bool:
	for k in cost.keys():
		if get_item_count(str(k)) < int(cost[k]):
			return false
	return true


func spend_resources(cost: Dictionary) -> void:
	for k in cost.keys():
		consume_item(str(k), int(cost[k]))


func craft_recipe(recipe: Dictionary) -> bool:
	var cost: Dictionary = recipe["cost"]
	if not has_resources(cost):
		toast_message.emit("الموارد غير كافية للتصنيع.")
		return false
	spend_resources(cost)
	var out_id := str(recipe["id"])
	var out_count := int(recipe["out_count"])
	add_item(out_id, out_count)
	AudioManager.play_sfx("craft")
	var ar_name := str(ItemRegistry.get_item(out_id).get("ar_name", out_id))
	toast_message.emit("تم تصنيع %s (x%d)" % [ar_name, out_count])
	return true


func take_damage(amount: float, play_sound: bool = true) -> void:
	health = maxf(0.0, health - amount)
	if play_sound:
		AudioManager.play_sfx("hurt")
	stats_changed.emit()
	if health <= 0.0:
		_respawn_player()


func _respawn_player() -> void:
	health = 100.0
	hunger = 80.0
	thirst = 80.0
	warmth = 80.0
	stamina = 100.0
	if _world != null:
		global_position = _world.get_safe_spawn_position(Vector2i(2, 2))
	velocity = Vector3.ZERO
	toast_message.emit("تمت إعادة الإحياء في نقطة الأمان.")
	player_died.emit()
	stats_changed.emit()


func _update_tool_visual() -> void:
	if tool_mesh == null:
		return
	var active_id := get_active_item_id()
	var mat := StandardMaterial3D.new()
	match active_id:
		"rock":
			mat.albedo_color = Color(0.54, 0.55, 0.57)
		"hatchet":
			mat.albedo_color = Color(0.68, 0.48, 0.30)
		"pickaxe":
			mat.albedo_color = Color(0.55, 0.62, 0.70)
		"hammer":
			mat.albedo_color = Color(0.85, 0.36, 0.15)
		"spear":
			mat.albedo_color = Color(0.72, 0.56, 0.34)
		"twig_block":
			mat.albedo_color = Color(0.58, 0.44, 0.26)
		_:
			mat.albedo_color = Color(0.65, 0.65, 0.65)
	tool_mesh.material_override = mat


func export_save_data() -> Dictionary:
	return {
		"health": health,
		"hunger": hunger,
		"thirst": thirst,
		"warmth": warmth,
		"inventory": inventory,
		"hotbar": hotbar
	}


func import_save_data(data: Dictionary) -> void:
	health = float(data.get("health", 100.0))
	hunger = float(data.get("hunger", 100.0))
	thirst = float(data.get("thirst", 100.0))
	warmth = float(data.get("warmth", 85.0))
	if typeof(data.get("inventory")) == TYPE_DICTIONARY:
		inventory = data["inventory"]
	if typeof(data.get("hotbar")) == TYPE_ARRAY:
		hotbar.clear()
		for item in data["hotbar"]:
			hotbar.append(str(item))
	stats_changed.emit()
	inventory_changed.emit()
