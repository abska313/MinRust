class_name VoxelWorld
extends Node3D
## Procedural 3D Voxel World with Rust Scrap Monuments, block damage/upgrading,
## campfire warmth zones, dynamic chunk streaming, and host-authoritative LAN sync.

signal world_ready()
signal block_changed(world_pos: Vector3i, new_block_id: int)

const WATER_LEVEL := 7
const REMOTE_PLAYER_SCENE := preload("res://scenes/remote_player.tscn")
const RAIDER_SCENE := preload("res://scenes/raider_enemy.tscn")

var chunks: Dictionary = {} # Vector2i -> VoxelChunk
var modified_blocks: Dictionary = {} # "x,y,z" -> int block_id
var block_hp: Dictionary = {} # "x,y,z" -> int current_hp
var campfire_lights: Dictionary = {} # "x,y,z" -> OmniLight3D
var tool_cupboards: Dictionary = {} # "x,y,z" -> int owner_peer_id
var remote_players: Dictionary = {} # peer_id -> RemotePlayer
var active_raiders: Array[Node3D] = []

var _noise: FastNoiseLite
var _ore_noise: FastNoiseLite
var _chunk_material: StandardMaterial3D
var _last_player_chunk: Vector2i = Vector2i(99999, 99999)
var _raider_spawn_timer: float = 0.0
var _local_player: Node3D = null
var _day_night: Node = null


func _ready() -> void:
	_setup_material()
	_setup_noise(GameConfig.world_seed)
	_day_night = get_node_or_null("../DayNightCycle")
	_local_player = get_node_or_null("../Player")

	if NetworkManager.is_networked():
		multiplayer.peer_connected.connect(_on_lan_peer_connected)
		multiplayer.peer_disconnected.connect(_on_lan_peer_disconnected)

	if GameConfig.load_saved_world and NetworkManager.is_host_authority():
		_load_from_save()

	# Initial chunks around spawn (0, 0)
	update_chunks_around(Vector3.ZERO)

	# Place player safely on ground after initial chunks generate
	if _local_player != null:
		var spawn_pos := get_safe_spawn_position(Vector2i(2, 2))
		if GameConfig.load_saved_world and SaveManager.has_save():
			var saved := SaveManager.load_world()
			if saved.has("player_pos"):
				var arr: Array = saved["player_pos"]
				if arr.size() == 3:
					spawn_pos = Vector3(float(arr[0]), float(arr[1]), float(arr[2]))
		_local_player.global_position = spawn_pos

	world_ready.emit()


func _process(delta: float) -> void:
	if _local_player != null:
		update_chunks_around(_local_player.global_position)

	# Rebuild any dirty chunks (budgeted per frame for smooth mobile FPS)
	var rebuilt := 0
	for chunk: VoxelChunk in chunks.values():
		if chunk.is_dirty:
			chunk.rebuild_mesh_and_collider()
			rebuilt += 1
			if rebuilt >= 2:
				break

	# Host spawns Night Raiders away from campfires
	if NetworkManager.is_host_authority() and _day_night != null and _local_player != null:
		_tick_raider_spawner(delta)


func _setup_material() -> void:
	_chunk_material = StandardMaterial3D.new()
	var tex := load("res://assets/textures/voxel_atlas.png")
	_chunk_material.albedo_texture = tex
	_chunk_material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	_chunk_material.vertex_color_use_as_albedo = true
	_chunk_material.roughness = 0.92
	_chunk_material.metallic = 0.04


func _setup_noise(seed_val: int) -> void:
	_noise = FastNoiseLite.new()
	_noise.seed = seed_val
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	_noise.frequency = 0.028
	_noise.fractal_octaves = 3

	_ore_noise = FastNoiseLite.new()
	_ore_noise.seed = seed_val + 9001
	_ore_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	_ore_noise.frequency = 0.14


func _key(p: Vector3i) -> String:
	return "%d,%d,%d" % [p.x, p.y, p.z]


func _world_to_chunk(wp: Vector3i) -> Vector2i:
	return Vector2i(floori(float(wp.x) / VoxelChunk.CHUNK_W), floori(float(wp.z) / VoxelChunk.CHUNK_D))


func update_chunks_around(world_pos: Vector3) -> void:
	var center := Vector2i(floori(world_pos.x / VoxelChunk.CHUNK_W), floori(world_pos.z / VoxelChunk.CHUNK_D))
	if center == _last_player_chunk:
		return
	_last_player_chunk = center
	var r := GameConfig.render_distance_chunks

	# Generate needed chunks
	for cz in range(center.y - r, center.y + r + 1):
		for cx in range(center.x - r, center.x + r + 1):
			var coord := Vector2i(cx, cz)
			if not chunks.has(coord):
				_create_chunk(coord)

	# Unload far chunks to keep mobile RAM lean
	var unload_dist := r + 2
	for coord: Vector2i in chunks.keys():
		if abs(coord.x - center.x) > unload_dist or abs(coord.y - center.y) > unload_dist:
			var ch: VoxelChunk = chunks[coord]
			chunks.erase(coord)
			ch.queue_free()


func _create_chunk(coord: Vector2i) -> void:
	var chunk := VoxelChunk.new()
	chunk.name = "Chunk_%d_%d" % [coord.x, coord.y]
	chunk.setup(coord, self, _chunk_material)
	add_child(chunk)
	chunks[coord] = chunk

	var base_wx := coord.x * VoxelChunk.CHUNK_W
	var base_wz := coord.y * VoxelChunk.CHUNK_D

	for lx in range(VoxelChunk.CHUNK_W):
		for lz in range(VoxelChunk.CHUNK_D):
			var wx := base_wx + lx
			var wz := base_wz + lz
			var h := _compute_surface_height(wx, wz)

			for y in range(VoxelChunk.CHUNK_H):
				var b_id := BlockRegistry.BlockID.AIR
				if y == 0:
					b_id = BlockRegistry.BlockID.BEDROCK
				elif y < h - 3:
					b_id = BlockRegistry.BlockID.STONE
					var ore_val := _ore_noise.get_noise_3d(wx, y, wz)
					if ore_val > 0.56:
						b_id = BlockRegistry.BlockID.IRON_ORE
					elif ore_val < -0.58:
						b_id = BlockRegistry.BlockID.SULFUR_ORE
				elif y < h:
					b_id = BlockRegistry.BlockID.SAND if h <= WATER_LEVEL + 1 else BlockRegistry.BlockID.DIRT
				elif y == h:
					b_id = BlockRegistry.BlockID.SAND if h <= WATER_LEVEL + 1 else BlockRegistry.BlockID.GRASS
				elif y <= WATER_LEVEL:
					b_id = BlockRegistry.BlockID.WATER

				chunk.set_local_block(lx, y, lz, b_id)

	# Deterministic trees & Rust scrap barrels/ruins per chunk
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(Vector3i(coord.x, coord.y, GameConfig.world_seed))

	# Spawn 2-4 pine/oak trees
	for _i in range(rng.randi_range(2, 4)):
		var tx := rng.randi_range(2, VoxelChunk.CHUNK_W - 3)
		var tz := rng.randi_range(2, VoxelChunk.CHUNK_D - 3)
		var th := _compute_surface_height(base_wx + tx, base_wz + tz)
		if th > WATER_LEVEL + 1 and th < VoxelChunk.CHUNK_H - 7:
			_stamp_tree(chunk, tx, th + 1, tz, rng.randi_range(4, 5))

	# Spawn Rust Scrap Monument / Loot Barrels in ~35% of chunks
	if rng.randf() < 0.35:
		var mx := rng.randi_range(4, VoxelChunk.CHUNK_W - 5)
		var mz := rng.randi_range(4, VoxelChunk.CHUNK_D - 5)
		var mh := _compute_surface_height(base_wx + mx, base_wz + mz)
		if mh > WATER_LEVEL + 1 and mh < VoxelChunk.CHUNK_H - 6:
			_stamp_rust_ruin(chunk, mx, mh + 1, mz)

	# Apply any player-saved/synced block modifications in this chunk
	for k: String in modified_blocks.keys():
		var parts := k.split(",")
		if parts.size() != 3:
			continue
		var wx := int(parts[0])
		var wy := int(parts[1])
		var wz := int(parts[2])
		if _world_to_chunk(Vector3i(wx, wy, wz)) == coord:
			var lx := posmod(wx, VoxelChunk.CHUNK_W)
			var lz := posmod(wz, VoxelChunk.CHUNK_D)
			var b_id := int(modified_blocks[k])
			chunk.set_local_block(lx, wy, lz, b_id)
			if b_id == BlockRegistry.BlockID.CAMPFIRE:
				_spawn_campfire_light(Vector3i(wx, wy, wz))

	chunk.rebuild_mesh_and_collider()


func _compute_surface_height(wx: int, wz: int) -> int:
	var n := _noise.get_noise_2d(wx, wz)
	return clampi(int(round(11.0 + n * 6.5)), 4, 21)


func _stamp_tree(chunk: VoxelChunk, lx: int, base_y: int, lz: int, height: int) -> void:
	for y in range(height):
		chunk.set_local_block(lx, base_y + y, lz, BlockRegistry.BlockID.WOOD_LOG)
	var top_y := base_y + height
	for dy in range(-1, 2):
		var rad := 2 if dy < 1 else 1
		for dx in range(-rad, rad + 1):
			for dz in range(-rad, rad + 1):
				if abs(dx) == rad and abs(dz) == rad and dy == 1:
					continue
				var cx := lx + dx
				var cz := lz + dz
				var cy := top_y + dy
				if chunk.get_local_block(cx, cy, cz) == BlockRegistry.BlockID.AIR:
					chunk.set_local_block(cx, cy, cz, BlockRegistry.BlockID.LEAVES)


func _stamp_rust_ruin(chunk: VoxelChunk, lx: int, base_y: int, lz: int) -> void:
	# Small rusted metal scrap shelter with 2 loot barrels
	for dx in range(-1, 2):
		chunk.set_local_block(lx + dx, base_y, lz - 1, BlockRegistry.BlockID.METAL_WALL)
		chunk.set_local_block(lx + dx, base_y + 1, lz - 1, BlockRegistry.BlockID.METAL_WALL)
	chunk.set_local_block(lx - 1, base_y, lz, BlockRegistry.BlockID.STONE_WALL)
	chunk.set_local_block(lx + 1, base_y, lz, BlockRegistry.BlockID.LOOT_BARREL)
	chunk.set_local_block(lx, base_y, lz + 1, BlockRegistry.BlockID.LOOT_BARREL)


func get_block_at(wp: Vector3i) -> int:
	if wp.y < 0 or wp.y >= VoxelChunk.CHUNK_H:
		return BlockRegistry.BlockID.AIR
	var k := _key(wp)
	if modified_blocks.has(k):
		return int(modified_blocks[k])
	var coord := _world_to_chunk(wp)
	if chunks.has(coord):
		var ch: VoxelChunk = chunks[coord]
		return ch.get_local_block(posmod(wp.x, VoxelChunk.CHUNK_W), wp.y, posmod(wp.z, VoxelChunk.CHUNK_D))
	return BlockRegistry.BlockID.AIR


func get_safe_spawn_position(xz: Vector2i) -> Vector3:
	for y in range(VoxelChunk.CHUNK_H - 3, 1, -1):
		var b := get_block_at(Vector3i(xz.x, y, xz.y))
		if BlockRegistry.is_solid(b):
			return Vector3(float(xz.x) + 0.5, float(y) + 1.15, float(xz.y) + 0.5)
	return Vector3(float(xz.x) + 0.5, 18.0, float(xz.y) + 0.5)


func raycast_voxel(origin: Vector3, dir: Vector3, max_dist: float = 5.5) -> Dictionary:
	# Clean fixed-step DDA voxel raycast for zero-tunneling block targeting
	var step := 0.06
	var dist := 0.0
	var last_air := Vector3i(floori(origin.x), floori(origin.y), floori(origin.z))
	while dist <= max_dist:
		var p := origin + dir * dist
		var vp := Vector3i(floori(p.x), floori(p.y), floori(p.z))
		var b := get_block_at(vp)
		if b != BlockRegistry.BlockID.AIR and b != BlockRegistry.BlockID.WATER:
			return {
				"hit": true,
				"block_pos": vp,
				"place_pos": last_air,
				"block_id": b,
				"hp": get_block_hp(vp, b),
				"max_hp": int(BlockRegistry.get_block(b)["max_hp"])
			}
		last_air = vp
		dist += step
	return {"hit": false}


func get_block_hp(wp: Vector3i, block_id: int) -> int:
	var k := _key(wp)
	if block_hp.has(k):
		return int(block_hp[k])
	return int(BlockRegistry.get_block(block_id)["max_hp"])


func request_damage_block(wp: Vector3i, damage: int) -> Dictionary:
	if NetworkManager.is_networked() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_damage_block", wp, damage)
		return {"broken": false, "pending": true}
	return _apply_damage_block_authoritative(wp, damage)


@rpc("any_peer", "reliable")
func _rpc_request_damage_block(wp: Vector3i, damage: int) -> void:
	if not multiplayer.is_server():
		return
	var clamped_dmg := clampi(damage, 1, 60)
	_apply_damage_block_authoritative(wp, clamped_dmg)


func _apply_damage_block_authoritative(wp: Vector3i, damage: int) -> Dictionary:
	var b_id := get_block_at(wp)
	if b_id == BlockRegistry.BlockID.AIR or b_id == BlockRegistry.BlockID.BEDROCK:
		return {"broken": false}
	var info := BlockRegistry.get_block(b_id)
	var k := _key(wp)
	var cur_hp := get_block_hp(wp, b_id) - damage
	if cur_hp <= 0:
		block_hp.erase(k)
		_set_block_everywhere(wp, BlockRegistry.BlockID.AIR)
		return {
			"broken": true,
			"drop_item": str(info["drop_item"]),
			"drop_count": int(info["drop_count"]),
			"was_barrel": b_id == BlockRegistry.BlockID.LOOT_BARREL
		}
	else:
		block_hp[k] = cur_hp
		return {"broken": false, "hp": cur_hp, "max_hp": int(info["max_hp"])}


func request_place_or_upgrade_block(wp: Vector3i, new_block_id: int) -> void:
	if NetworkManager.is_networked() and not multiplayer.is_server():
		rpc_id(1, "_rpc_request_set_block", wp, new_block_id)
		return
	_set_block_everywhere(wp, new_block_id)


@rpc("any_peer", "reliable")
func _rpc_request_set_block(wp: Vector3i, new_block_id: int) -> void:
	if not multiplayer.is_server():
		return
	if wp.y <= 0 or wp.y >= VoxelChunk.CHUNK_H - 1:
		return
	_set_block_everywhere(wp, new_block_id)


func _set_block_everywhere(wp: Vector3i, new_block_id: int) -> void:
	if NetworkManager.is_networked():
		rpc("_rpc_apply_block", wp, new_block_id)
	else:
		_apply_block_local(wp, new_block_id)


@rpc("authority", "call_local", "reliable")
func _rpc_apply_block(wp: Vector3i, new_block_id: int) -> void:
	_apply_block_local(wp, new_block_id)


func _apply_block_local(wp: Vector3i, new_block_id: int) -> void:
	if wp.y < 0 or wp.y >= VoxelChunk.CHUNK_H:
		return
	var k := _key(wp)
	modified_blocks[k] = new_block_id
	block_hp.erase(k)

	# Campfire light management
	if new_block_id == BlockRegistry.BlockID.CAMPFIRE:
		_spawn_campfire_light(wp)
	elif campfire_lights.has(k):
		var light: OmniLight3D = campfire_lights[k]
		campfire_lights.erase(k)
		if is_instance_valid(light):
			light.queue_free()

	if new_block_id == BlockRegistry.BlockID.TOOL_CUPBOARD:
		tool_cupboards[k] = multiplayer.get_unique_id() if NetworkManager.is_networked() else 1
	elif tool_cupboards.has(k):
		tool_cupboards.erase(k)

	var coord := _world_to_chunk(wp)
	var lx := posmod(wp.x, VoxelChunk.CHUNK_W)
	var lz := posmod(wp.z, VoxelChunk.CHUNK_D)
	if chunks.has(coord):
		var ch: VoxelChunk = chunks[coord]
		ch.set_local_block(lx, wp.y, lz, new_block_id)
		# Mark neighboring chunks dirty if block is on a chunk border
		if lx == 0 and chunks.has(coord + Vector2i(-1, 0)):
			chunks[coord + Vector2i(-1, 0)].is_dirty = true
		elif lx == VoxelChunk.CHUNK_W - 1 and chunks.has(coord + Vector2i(1, 0)):
			chunks[coord + Vector2i(1, 0)].is_dirty = true
		if lz == 0 and chunks.has(coord + Vector2i(0, -1)):
			chunks[coord + Vector2i(0, -1)].is_dirty = true
		elif lz == VoxelChunk.CHUNK_D - 1 and chunks.has(coord + Vector2i(0, 1)):
			chunks[coord + Vector2i(0, 1)].is_dirty = true

	block_changed.emit(wp, new_block_id)


func _spawn_campfire_light(wp: Vector3i) -> void:
	var k := _key(wp)
	if campfire_lights.has(k):
		return
	var light := OmniLight3D.new()
	light.position = Vector3(wp.x + 0.5, wp.y + 1.25, wp.z + 0.5)
	light.light_color = Color(1.0, 0.58, 0.22)
	light.light_energy = 2.6
	light.omni_range = 9.0
	add_child(light)
	campfire_lights[k] = light


func is_near_campfire(world_pos: Vector3, radius: float = 6.5) -> bool:
	for light: OmniLight3D in campfire_lights.values():
		if is_instance_valid(light) and light.global_position.distance_to(world_pos) <= radius:
			return true
	return false


func is_protected_by_tc(world_pos: Vector3, radius: float = 12.0) -> bool:
	for k: String in tool_cupboards.keys():
		var parts := k.split(",")
		if parts.size() == 3:
			var p := Vector3(float(parts[0]), float(parts[1]), float(parts[2]))
			if p.distance_to(world_pos) <= radius:
				return true
	return false


func _tick_raider_spawner(delta: float) -> void:
	# Clean dead/far raiders
	for i in range(active_raiders.size() - 1, -1, -1):
		var r := active_raiders[i]
		if not is_instance_valid(r):
			active_raiders.remove_at(i)
		elif r.global_position.distance_to(_local_player.global_position) > 48.0:
			r.queue_free()
			active_raiders.remove_at(i)

	var max_raiders := 3 if _day_night.is_night() else 1
	if active_raiders.size() >= max_raiders:
		return

	_raider_spawn_timer += delta
	if _raider_spawn_timer < 18.0:
		return
	_raider_spawn_timer = 0.0

	var angle := randf() * TAU
	var dist := randf_range(16.0, 24.0)
	var sx := int(round(_local_player.global_position.x + cos(angle) * dist))
	var sz := int(round(_local_player.global_position.z + sin(angle) * dist))
	var spawn_p := get_safe_spawn_position(Vector2i(sx, sz))
	if is_near_campfire(spawn_p, 8.0) or is_protected_by_tc(spawn_p, 10.0):
		return

	var raider := RAIDER_SCENE.instantiate()
	add_child(raider)
	raider.global_position = spawn_p
	active_raiders.append(raider)


# --- LAN Player Synchronization ---
func _on_lan_peer_connected(peer_id: int) -> void:
	if multiplayer.is_server():
		# Send world seed and modified blocks to newly joined family player
		rpc_id(peer_id, "_rpc_sync_full_world", GameConfig.world_seed, modified_blocks)
	_spawn_remote_player(peer_id)


func _on_lan_peer_disconnected(peer_id: int) -> void:
	if remote_players.has(peer_id):
		var rp = remote_players[peer_id]
		remote_players.erase(peer_id)
		if is_instance_valid(rp):
			rp.queue_free()


func _spawn_remote_player(peer_id: int) -> void:
	if remote_players.has(peer_id):
		return
	var rp := REMOTE_PLAYER_SCENE.instantiate()
	rp.name = "RemotePlayer_%d" % peer_id
	add_child(rp)
	rp.global_position = get_safe_spawn_position(Vector2i(2, 2))
	var pname := str(NetworkManager.peers_info.get(peer_id, {}).get("name", "Player_%d" % peer_id))
	rp.set_player_label(pname)
	remote_players[peer_id] = rp


@rpc("authority", "reliable")
func _rpc_sync_full_world(seed_val: int, mod_dict: Dictionary) -> void:
	GameConfig.world_seed = seed_val
	_setup_noise(seed_val)
	modified_blocks = mod_dict.duplicate(true)
	for ch: VoxelChunk in chunks.values():
		ch.queue_free()
	chunks.clear()
	_last_player_chunk = Vector2i(99999, 99999)
	if _local_player != null:
		update_chunks_around(_local_player.global_position)


func broadcast_local_player_state(pos: Vector3, yaw: float, swinging: bool) -> void:
	if not NetworkManager.is_networked():
		return
	rpc("_rpc_update_remote_player", pos, yaw, swinging, GameConfig.player_name)


@rpc("any_peer", "unreliable_ordered")
func _rpc_update_remote_player(pos: Vector3, yaw: float, swinging: bool, pname: String) -> void:
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id == multiplayer.get_unique_id():
		return
	if not remote_players.has(sender_id):
		_spawn_remote_player(sender_id)
	var rp = remote_players[sender_id]
	if is_instance_valid(rp):
		rp.apply_network_state(pos, yaw, swinging, pname)


# --- Save / Load ---
func save_game_now() -> bool:
	if _local_player == null:
		return false
	var data := {
		"seed": GameConfig.world_seed,
		"modified_blocks": modified_blocks,
		"time_of_day": _day_night.time_of_day if _day_night != null else 0.35,
		"day_count": _day_night.day_count if _day_night != null else 1,
		"player_pos": [_local_player.global_position.x, _local_player.global_position.y, _local_player.global_position.z],
		"player_stats": _local_player.export_save_data()
	}
	return SaveManager.save_world(data)


func _load_from_save() -> void:
	var saved := SaveManager.load_world()
	if saved.is_empty():
		return
	GameConfig.world_seed = int(saved.get("seed", GameConfig.world_seed))
	_setup_noise(GameConfig.world_seed)
	if typeof(saved.get("modified_blocks")) == TYPE_DICTIONARY:
		modified_blocks = saved["modified_blocks"]
	if _day_night != null:
		_day_night.time_of_day = float(saved.get("time_of_day", 0.35))
		_day_night.day_count = int(saved.get("day_count", 1))
	if _local_player != null and typeof(saved.get("player_stats")) == TYPE_DICTIONARY:
		_local_player.import_save_data(saved["player_stats"])
