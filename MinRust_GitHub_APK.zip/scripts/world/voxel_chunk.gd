class_name VoxelChunk
extends StaticBody3D
## Single 16x32x16 voxel chunk with face-culled ArrayMesh rendering and exact solid collision geometry.

const CHUNK_W := 16
const CHUNK_H := 32
const CHUNK_D := 16

var chunk_coord: Vector2i = Vector2i.ZERO
var blocks: PackedByteArray = PackedByteArray()
var is_dirty: bool = false

var _mesh_instance: MeshInstance3D
var _collision_shape: CollisionShape3D
var _world_ref: Node = null

# Face definitions: normal, 4 counter-clockwise vertices, brightness shading
const FACES := [
	{
		"dir": Vector3i(0, 1, 0), "slot": "top", "shade": 1.0,
		"verts": [Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(0, 1, 1)]
	},
	{
		"dir": Vector3i(0, -1, 0), "slot": "bottom", "shade": 0.58,
		"verts": [Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(1, 0, 0), Vector3(0, 0, 0)]
	},
	{
		"dir": Vector3i(1, 0, 0), "slot": "side", "shade": 0.84,
		"verts": [Vector3(1, 1, 1), Vector3(1, 1, 0), Vector3(1, 0, 0), Vector3(1, 0, 1)]
	},
	{
		"dir": Vector3i(-1, 0, 0), "slot": "side", "shade": 0.78,
		"verts": [Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(0, 0, 1), Vector3(0, 0, 0)]
	},
	{
		"dir": Vector3i(0, 0, 1), "slot": "side", "shade": 0.90,
		"verts": [Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 0, 1), Vector3(0, 0, 1)]
	},
	{
		"dir": Vector3i(0, 0, -1), "slot": "side", "shade": 0.72,
		"verts": [Vector3(1, 1, 0), Vector3(0, 1, 0), Vector3(0, 0, 0), Vector3(1, 0, 0)]
	},
]


func setup(coord: Vector2i, world_ref: Node, shared_material: StandardMaterial3D) -> void:
	chunk_coord = coord
	_world_ref = world_ref
	position = Vector3(coord.x * CHUNK_W, 0.0, coord.y * CHUNK_D)
	collision_layer = 1 # WorldTerrain
	collision_mask = 0

	blocks.resize(CHUNK_W * CHUNK_H * CHUNK_D)
	blocks.fill(BlockRegistry.BlockID.AIR)

	_mesh_instance = MeshInstance3D.new()
	_mesh_instance.material_override = shared_material
	_mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(_mesh_instance)

	_collision_shape = CollisionShape3D.new()
	add_child(_collision_shape)


func _idx(x: int, y: int, z: int) -> int:
	return x + z * CHUNK_W + y * CHUNK_W * CHUNK_D


func set_local_block(x: int, y: int, z: int, block_id: int) -> void:
	if x < 0 or x >= CHUNK_W or y < 0 or y >= CHUNK_H or z < 0 or z >= CHUNK_D:
		return
	blocks[_idx(x, y, z)] = block_id
	is_dirty = true


func get_local_block(x: int, y: int, z: int) -> int:
	if x < 0 or x >= CHUNK_W or y < 0 or y >= CHUNK_H or z < 0 or z >= CHUNK_D:
		return BlockRegistry.BlockID.AIR
	return blocks[_idx(x, y, z)]


func rebuild_mesh_and_collider() -> void:
	is_dirty = false
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	var collision_faces := PackedVector3Array()
	var base_wx := chunk_coord.x * CHUNK_W
	var base_wz := chunk_coord.y * CHUNK_D

	for y in range(CHUNK_H):
		for z in range(CHUNK_D):
			for x in range(CHUNK_W):
				var b_id := blocks[_idx(x, y, z)]
				if b_id == BlockRegistry.BlockID.AIR:
					continue
				var b_info := BlockRegistry.get_block(b_id)
				var is_solid_block := bool(b_info["solid"])
				var pos := Vector3(x, y, z)

				for face in FACES:
					var d: Vector3i = face["dir"]
					var nx := x + d.x
					var ny := y + d.y
					var nz := z + d.z

					var neighbor_id := BlockRegistry.BlockID.AIR
					if ny < 0 or ny >= CHUNK_H:
						neighbor_id = BlockRegistry.BlockID.AIR
					elif nx >= 0 and nx < CHUNK_W and nz >= 0 and nz < CHUNK_D:
						neighbor_id = blocks[_idx(nx, ny, nz)]
					elif _world_ref != null:
						neighbor_id = _world_ref.get_block_at(Vector3i(base_wx + nx, ny, base_wz + nz))

					# Cull shared opaque faces; avoid double faces between adjacent water blocks
					if b_id == BlockRegistry.BlockID.WATER and neighbor_id == BlockRegistry.BlockID.WATER:
						continue
					if neighbor_id != BlockRegistry.BlockID.AIR and not BlockRegistry.is_transparent(neighbor_id):
						continue

					var tile_idx: int = int(b_info[face["slot"]])
					var uv_rect := BlockRegistry.get_tile_uv(tile_idx)
					var shade: float = float(face["shade"])
					var col := Color(shade, shade, shade, 1.0)
					var normal := Vector3(d.x, d.y, d.z)
					var verts: Array = face["verts"]

					var v0: Vector3 = pos + verts[0]
					var v1: Vector3 = pos + verts[1]
					var v2: Vector3 = pos + verts[2]
					var v3: Vector3 = pos + verts[3]

					var uv0 := Vector2(uv_rect.position.x, uv_rect.position.y)
					var uv1 := Vector2(uv_rect.end.x, uv_rect.position.y)
					var uv2 := Vector2(uv_rect.end.x, uv_rect.end.y)
					var uv3 := Vector2(uv_rect.position.x, uv_rect.end.y)

					# Triangle 1 (v0, v1, v2)
					st.set_normal(normal)
					st.set_color(col)
					st.set_uv(uv0)
					st.add_vertex(v0)
					st.set_uv(uv1)
					st.add_vertex(v1)
					st.set_uv(uv2)
					st.add_vertex(v2)

					# Triangle 2 (v0, v2, v3)
					st.set_uv(uv0)
					st.add_vertex(v0)
					st.set_uv(uv2)
					st.add_vertex(v2)
					st.set_uv(uv3)
					st.add_vertex(v3)

					# Only solid blocks contribute to physics collision
					if is_solid_block:
						collision_faces.append(v0)
						collision_faces.append(v1)
						collision_faces.append(v2)
						collision_faces.append(v0)
						collision_faces.append(v2)
						collision_faces.append(v3)

	var mesh := st.commit()
	_mesh_instance.mesh = mesh

	if collision_faces.size() > 0:
		var shape := ConcavePolygonShape3D.new()
		shape.set_faces(collision_faces)
		_collision_shape.shape = shape
	else:
		_collision_shape.shape = null
