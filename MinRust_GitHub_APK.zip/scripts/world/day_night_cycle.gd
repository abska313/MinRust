class_name DayNightCycle
extends Node3D
## Dynamic Rust-style Day/Night lighting, sky color, fog, and temperature modifier.

const DAY_LENGTH_SECONDS := 480.0 # 8 real-time minutes per full day/night cycle

var time_of_day: float = 0.32 # 0.0 = midnight, 0.25 = dawn, 0.5 = noon, 0.75 = dusk
var day_count: int = 1

@onready var sun_light: DirectionalLight3D = $SunLight
@onready var world_env: WorldEnvironment = $WorldEnvironment


func _process(delta: float) -> void:
	time_of_day += delta / DAY_LENGTH_SECONDS
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_count += 1

	var sun_angle := (time_of_day - 0.25) * TAU
	if sun_light != null:
		sun_light.rotation.x = -sun_angle
		var elevation := sin(sun_angle)
		sun_light.light_energy = clampf(elevation * 1.35 + 0.15, 0.08, 1.35)
		if elevation > 0.15:
			sun_light.light_color = Color(1.0, 0.96, 0.88)
		elif elevation > -0.1:
			sun_light.light_color = Color(1.0, 0.62, 0.35) # Rust sunset/sunrise glow
		else:
			sun_light.light_color = Color(0.35, 0.48, 0.72) # Moonlight

	if world_env != null and world_env.environment != null:
		var day_factor := clampf(sin(sun_angle) * 1.4 + 0.35, 0.0, 1.0)
		var sky_col := Color(0.06, 0.08, 0.14).lerp(Color(0.48, 0.70, 0.90), day_factor)
		world_env.environment.background_color = sky_col
		world_env.environment.fog_light_color = sky_col
		world_env.environment.ambient_light_energy = lerpf(0.24, 0.72, day_factor)


func is_night() -> bool:
	return time_of_day < 0.22 or time_of_day > 0.78


func get_clock_string() -> String:
	var total_minutes := int(time_of_day * 1440.0)
	var hh := (total_minutes / 60) % 24
	var mm := total_minutes % 60
	return "Day %d | %02d:%02d" % [day_count, hh, mm]
